# SOFAPy 框架应用模板

## 快速开始

> ⛔ **禁止手动创建项目框架代码！**
>
> 本项目必须通过脚手架服务初始化，手动创建会导致目录结构不规范、配置文件缺失、内置 Skill 未集成等问题。
>
> Coding Agent 请勿手动生成框架代码，必须通过脚手架命令下载。

脚手架代码下载有两种方式：

### 方式一：通过命令下载（Coding Agent 必须使用）

**1. 安装 sofapy-developer skill**

```bash
python -m ensurepip --upgrade
# 安装 antskill-cli
python -m pip install --upgrade -i https://pypi.antfin-inc.com/simple-dev/ antskill-cli

python -m antskill_cli install sofapy-developer --client claude
python -m antskill_cli install sofapy-developer --client codefuse
```

**2. 下载脚手架代码**

启动 Coding Agent 后，输入以下指令：

```
下载脚手架代码，应用名称为 <appname>，服务类型为 <web/rpc/mcp>，中间件为 <中间件列表>
```

**参数说明：**

- **应用名称**：小写字母和数字，1-20 字符
- **服务类型**：web（HTTP API）/ rpc（SOFA RPC）/ mcp（AI 工具服务），可多选
- **中间件**：根据业务需要选择，可选值见下表

**可用中间件：**

| 中间件 | 用途 |
|--------|------|
| zcache | 分布式缓存 |
| zdas | 数据库服务 |
| ddsoss | 对象存储 |
| drm | 动态配置 |
| mist | 机密管理 |
| lock | 分布式锁 |
| maya | AI 推理服务 |
| sofamq / sofamqx / msgbroker | 消息队列 |
| tr | TR 调用（调用其他 TR 服务） |
| mcp | MCP 调用（调用其他 MCP Server） |

**示例指令：**

```
下载脚手架，应用名称为 demoapp，服务类型为 web，中间件为 zcache, zdas
```

```
下载脚手架，应用名称为 myaitools，服务类型为 mcp 和 rpc，中间件为 maya, zcache
```

### 方式二：通过在线服务下载（人工操作）

访问 [脚手架在线服务](https://sofapy-start.alipay.com/]，在线配置并下载脚手架代码。

> 此方式供开发者人工操作，Coding Agent 请使用方式一。

### 后续开发

脚手架代码下载后，可继续通过 Coding Agent 完成以下步骤（sofapy-developer skill 内置相关开发指南）：

**本地环境初始化（首次需执行）：**
- 安装 uv 包管理工具
- 安装并配置 Layotto(Mosn)
- 创建虚拟环境并安装依赖

**业务开发（在脚手架生成的框架代码基础上进行）：**
- 开发 Web 接口 / SOFA RPC 服务 / MCP 服务
- 配置 SOFA 中间件
- 日志、链路追踪等

## 参考资源

- 官方文档（框架说明、最佳实践等）：https://yuque.antfin.com/middleware/sofa-py/sofapy-base
- 代码脚手架在线服务：https://sofapy-start.alipay.com/