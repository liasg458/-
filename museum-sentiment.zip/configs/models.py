"""
硅基流动(SiliconFlow) API 配置
文档: https://docs.siliconflow.cn/
"""

# SiliconFlow API配置
SILICONFLOW_CONFIG = {
    "base_url": "https://api.siliconflow.cn/v1",
    "api_key": "",  # 在 configs/api_key.txt 中填写
}

# 对比模型列表（名称已与硅基流动平台对齐）
MODELS = {
    "qwen": {
        "name": "Qwen/Qwen2.5-72B-Instruct",
        "label": "通义千问72B",
        "desc": "阿里通义千问，中文理解最强之一",
    },
    "deepseek": {
        "name": "deepseek-ai/DeepSeek-V3",
        "label": "DeepSeek-V3",
        "desc": "深度求索，推理能力强，性价比高",
    },
    "glm": {
        "name": "THUDM/GLM-4-9B-0414",
        "label": "GLM-4-9B",
        "desc": "智谱ChatGLM，中文对话能力强，速度快",
    },
}

# 标注配置
LABEL_CONFIG = {
    "sentiment_labels": ["positive", "neutral", "negative"],
    "risk_dimensions": ["product", "culture", "marketing", "audience"],
    "batch_size": 10,  # 每次API调用处理的文本数
    "max_retries": 3,
    "timeout": 30,
}
