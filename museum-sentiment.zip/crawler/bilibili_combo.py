"""B站组合关键词搜索 - 多线程"""
import json, os, re, sys, time, random
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords_combo import MUSEUMS, CATEGORIES
from configs.keywords import RISK_KEYWORDS

def gen_keywords():
    kws = []
    for m in MUSEUMS[:50]:
        for c in CATEGORIES[:20]:
            kws.append(f"{m}{c}")
    kws.extend(RISK_KEYWORDS)
    return list(dict.fromkeys(kws))

class BiliComboCrawler:
    def __init__(self, num_threads=10):
        self.save_dir = Path("data/raw/bilibili")
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Referer": "https://search.bilibili.com/",
            "Accept": "application/json",
        }
        self.num_threads = num_threads

    def search_single(self, keyword):
        url = "https://api.bilibili.com/x/web-interface/search/type"
        results = []
        for page in range(1, 6):  # 每词5页
            params = {"search_type": "video", "keyword": keyword, "page": page, "order": "pubdate"}
            try:
                resp = requests.get(url, params=params, headers=self.headers, timeout=10)
                data = resp.json()
                items = data.get("data", {}).get("result", [])
                if not items:
                    break
                for v in items:
                    title = re.sub(r"<[^>]+>", "", v.get("title", ""))
                    desc = re.sub(r"<[^>]+>", "", v.get("description", ""))
                    text = f"{title} {desc}".strip()
                    if text and len(text) >= 5:
                        results.append({
                            "id": str(v.get("bvid", "")),
                            "text": text, "title": title, "description": desc,
                            "user_name": v.get("author", ""),
                            "play_count": v.get("play", 0),
                            "reply_count": v.get("review", 0),
                            "keyword": keyword,
                            "platform": "bilibili",
                        })
                time.sleep(random.uniform(0.3, 0.8))
            except:
                break
        return keyword, results

    def crawl(self):
        keywords = gen_keywords()
        print(f"关键词数: {len(keywords)}, 线程: {self.num_threads}")
        all_data = []
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = {executor.submit(self.search_single, kw): kw for kw in keywords}
            pbar = tqdm(total=len(futures), desc="B站组合")
            for future in as_completed(futures):
                kw, items = future.result()
                all_data.extend(items)
                pbar.update(1)
                if items:
                    pbar.write(f"  [{kw}] {len(items)}条，累计{len(all_data)}条")
            pbar.close()

        df = pd.DataFrame(all_data)
        if not df.empty:
            df = df.drop_duplicates(subset=["id"])
        filename = self.save_dir / f"bilibili_combo_{ts}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df

if __name__ == "__main__":
    print("=" * 60)
    print("  B站组合关键词搜索 - 多线程")
    print("=" * 60)
    crawler = BiliComboCrawler(num_threads=10)
    df = crawler.crawl()
    print(f"\n完成！共 {len(df)} 条")
