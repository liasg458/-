"""
B站评论采集器 - 给已采集的视频拉评论
每个视频拉取前5页评论，大幅增加数据量

使用方式: python crawler/bilibili_comments.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import requests
import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))


class BilibiliCommentCrawler:
    """B站评论采集器"""

    def __init__(self, cookie: str = ""):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
            "Cookie": cookie,
            "Referer": "https://www.bilibili.com/",
            "Accept": "application/json, text/plain, */*",
        })
        self.save_dir = Path("data/raw/bilibili")
        self.save_dir.mkdir(parents=True, exist_ok=True)

    def get_comments(self, aid: str, max_pages: int = 5) -> list:
        """获取视频评论"""
        all_comments = []
        for page in range(1, max_pages + 1):
            url = "https://api.bilibili.com/x/v2/reply"
            params = {
                "oid": aid,
                "type": 1,
                "pn": page,
                "ps": 20,
                "order": "time",
            }
            try:
                resp = self.session.get(url, params=params, timeout=15)
                resp.raise_for_status()
                data = resp.json()
                if data.get("code") != 0:
                    break
                replies = data.get("data", {}).get("replies", [])
                if not replies:
                    break
                for r in replies:
                    content = r.get("content", {}).get("message", "")
                    if content and len(content) >= 5:
                        all_comments.append({
                            "id": str(r.get("rpid", "")),
                            "text": content,
                            "user_name": r.get("member", {}).get("uname", ""),
                            "user_mid": str(r.get("mid", "")),
                            "like_count": r.get("like", 0),
                            "reply_count": r.get("rcount", 0),
                            "ctime": r.get("ctime", 0),
                            "video_aid": str(aid),
                            "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "platform": "bilibili_comment",
                        })
                time.sleep(random.uniform(0.5, 1.5))
            except:
                break
        return all_comments

    def crawl_comments(self, video_csv: str, max_pages_per_video: int = 5) -> pd.DataFrame:
        """从已采集的视频CSV中读取视频列表，采集评论"""
        df = pd.read_csv(video_csv)
        print(f"视频总数: {len(df)}，每个视频采集{max_pages_per_video}页评论")

        all_comments = []
        for idx, row in tqdm(df.iterrows(), total=len(df), desc="视频评论"):
            aid = row.get("aid", "")
            if not aid:
                continue
            comments = self.get_comments(aid, max_pages_per_video)
            # 填充关键词信息
            for c in comments:
                c["keyword"] = row.get("keyword", "")
            all_comments.extend(comments)

        comments_df = pd.DataFrame(all_comments)
        if not comments_df.empty:
            before = len(comments_df)
            comments_df = comments_df.drop_duplicates(subset=["id"])
            after = len(comments_df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"bilibili_comments_{timestamp}.csv"
        comments_df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(comments_df)}条)")
        return comments_df


if __name__ == "__main__":
    print("=" * 60)
    print("  B站评论采集器")
    print("=" * 60)

    # 找最新的B站视频CSV
    bili_files = sorted(Path("data/raw/bilibili").glob("bilibili_*.csv"))
    # 排除comments文件
    bili_files = [f for f in bili_files if "comment" not in f.name]
    if not bili_files:
        print("未找到B站视频数据！")
        exit(1)

    latest = bili_files[-1]
    print(f"视频数据: {latest}")

    crawler = BilibiliCommentCrawler()
    df = crawler.crawl_comments(str(latest), max_pages_per_video=5)

    print(f"\n采集完成！共 {len(df)} 条评论")
