"""
B站评论采集器 - Playwright版
用浏览器拦截评论API，绕过412反爬限制

使用方式: python crawler/bilibili_comments_pw.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))


class BilibiliCommentCrawler:
    """B站评论采集器 - Playwright拦截API"""

    def __init__(self):
        cfg = {"save_dir": "data/raw/bilibili"}
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)

        from playwright.sync_api import sync_playwright
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=True)
        self.context = self.browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36",
        )
        self.page = self.context.new_page()

    def get_comments_for_video(self, bvid: str) -> list:
        """访问视频页面，拦截评论API"""
        collected = []
        page = self.page

        def handle_response(response):
            url = response.url
            # B站评论API
            if "reply" in url and ("v2" in url or "v1" in url) and "bilibili" in url:
                try:
                    data = response.json()
                    replies = data.get("data", {}).get("replies", [])
                    if not replies:
                        replies = data.get("data", {}).get("replies", [])
                    for r in replies:
                        content = r.get("content", {}).get("message", "")
                        if content and len(content) >= 5:
                            collected.append({
                                "text": content,
                                "user_name": r.get("member", {}).get("uname", ""),
                                "like_count": r.get("like", 0),
                                "reply_count": r.get("rcount", 0),
                                "video_bvid": bvid,
                            })
                except:
                    pass

        page.on("response", handle_response)

        try:
            url = f"https://www.bilibili.com/video/{bvid}"
            page.goto(url, timeout=15000, wait_until="domcontentloaded")
            time.sleep(2)

            # 滚动到评论区
            page.evaluate("window.scrollTo(0, 600)")
            time.sleep(2)

            # 再滚动一下加载更多
            page.evaluate("window.scrollTo(0, 1200)")
            time.sleep(1)
        except:
            pass

        page.remove_listener("response", handle_response)
        return collected

    def crawl(self, video_csv: str, max_videos: int = 702) -> pd.DataFrame:
        df = pd.read_csv(video_csv)
        if len(df) > max_videos:
            df = df.head(max_videos)
        print(f"视频总数: {len(df)}")

        all_comments = []
        for idx, row in tqdm(df.iterrows(), total=len(df), desc="B站评论"):
            bvid = str(row.get("id", "")).strip()
            if not bvid or bvid == "nan":
                continue

            comments = self.get_comments_for_video(bvid)
            for c in comments:
                c["keyword"] = row.get("keyword", "")
                c["crawl_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                c["platform"] = "bilibili_comment"
            all_comments.extend(comments)

            if len(all_comments) % 2000 == 0 and len(all_comments) > 0:
                print(f"  已采集评论: {len(all_comments)}条")

            time.sleep(random.uniform(0.5, 1.5))

        result_df = pd.DataFrame(all_comments)
        if not result_df.empty:
            before = len(result_df)
            result_df = result_df.drop_duplicates(subset=["text", "video_bvid"])
            after = len(result_df)
            print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"bilibili_comments_{timestamp}.csv"
        result_df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(result_df)}条)")
        return result_df

    def close(self):
        self.browser.close()
        self.playwright.stop()


if __name__ == "__main__":
    print("=" * 60)
    print("  B站评论采集器 - Playwright")
    print("=" * 60)

    bili_files = [f for f in sorted(Path("data/raw/bilibili").glob("bilibili_*.csv"))
                  if "comment" not in f.name and "danmaku" not in f.name]
    if not bili_files:
        print("未找到B站视频数据！")
        exit(1)

    latest = bili_files[-1]
    print(f"视频数据: {latest}")

    crawler = BilibiliCommentCrawler()
    try:
        df = crawler.crawl(str(latest))
        print(f"\n采集完成！共 {len(df)} 条评论")
    finally:
        crawler.close()
