"""
B站弹幕采集器 - 通过protobuf API获取弹幕
弹幕是B站最大的文本数据来源

使用方式: python crawler/bilibili_danmaku.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import requests
import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))


class BilibiliDanmakuCrawler:
    """B站弹幕采集器"""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.bilibili.com/",
        })
        self.save_dir = Path("data/raw/bilibili")
        self.save_dir.mkdir(parents=True, exist_ok=True)

    def get_video_info(self, bvid: str) -> dict:
        """获取视频信息（cid等）"""
        url = f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}"
        try:
            resp = self.session.get(url, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            if data.get("code") == 0:
                return data["data"]
        except:
            pass
        return {}

    def parse_danmaku_protobuf(self, content: bytes) -> list:
        """解析B站弹幕protobuf格式"""
        danmaku_list = []
        try:
            # B站弹幕protobuf格式
            # 每条弹幕的文本字段前面有特定的标记字节
            # 文本字段是 field 7 (wire type 2 = length-delimited)
            # 标记: 0x3a (field 7, wire type 2) + varint长度 + UTF-8文本

            i = 0
            while i < len(content):
                # 查找field 7标记 (0x3a)
                if content[i] == 0x3a:
                    i += 1
                    # 读取varint长度
                    length = 0
                    shift = 0
                    while i < len(content):
                        b = content[i]
                        i += 1
                        length |= (b & 0x7F) << shift
                        if b < 128:
                            break
                        shift += 7

                    if length > 0 and length < 500 and i + length <= len(content):
                        try:
                            text = content[i:i+length].decode("utf-8")
                            if text and len(text) >= 2 and any(
                                '\u4e00' <= c <= '\u9fff' or
                                c.isalpha() or
                                c in '，。！？、（）【】《》""''…—'
                                for c in text
                            ):
                                danmaku_list.append(text)
                        except:
                            pass
                        i += length
                    else:
                        i += 1
                else:
                    i += 1
        except:
            pass

        return danmaku_list

    def get_danmaku(self, cid: str, bvid: str, max_segments: int = 3) -> list:
        """获取弹幕"""
        all_danmaku = []
        for seg_idx in range(1, max_segments + 1):
            url = f"https://api.bilibili.com/x/v2/dm/web/seg.so?type=1&oid={cid}&segment_index={seg_idx}"
            try:
                resp = self.session.get(url, timeout=10)
                if resp.status_code != 200 or len(resp.content) < 10:
                    break

                texts = self.parse_danmaku_protobuf(resp.content)
                if not texts:
                    break

                all_danmaku.extend(texts)
                time.sleep(0.2)
            except:
                break

        # 去重
        seen = set()
        unique = []
        for t in all_danmaku:
            t = t.strip()
            if t and t not in seen:
                seen.add(t)
                unique.append(t)

        return unique

    def crawl(self, video_csv: str) -> pd.DataFrame:
        """批量采集弹幕"""
        df = pd.read_csv(video_csv)
        print(f"视频总数: {len(df)}")

        all_data = []
        for idx, row in tqdm(df.iterrows(), total=len(df), desc="弹幕采集"):
            bvid = str(row.get("id", "")).strip()

            if not bvid or bvid == "nan":
                continue

            # 获取视频信息
            info = self.get_video_info(bvid)
            if not info:
                continue

            cid = info.get("cid")
            if not cid:
                continue

            # 获取弹幕
            danmaku_texts = self.get_danmaku(cid, bvid)

            for text in danmaku_texts:
                all_data.append({
                    "text": text,
                    "video_bvid": bvid,
                    "video_title": info.get("title", ""),
                    "keyword": row.get("keyword", ""),
                    "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "platform": "bilibili_danmaku",
                })

            if len(all_data) % 1000 == 0 and len(all_data) > 0:
                print(f"  已采集弹幕: {len(all_data)}条")

            time.sleep(random.uniform(0.3, 0.8))

        result_df = pd.DataFrame(all_data)
        if not result_df.empty:
            before = len(result_df)
            result_df = result_df.drop_duplicates(subset=["text", "video_bvid"])
            after = len(result_df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"bilibili_danmaku_{timestamp}.csv"
        result_df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(result_df)}条)")
        return result_df


if __name__ == "__main__":
    print("=" * 60)
    print("  B站弹幕采集器")
    print("=" * 60)

    bili_files = [f for f in sorted(Path("data/raw/bilibili").glob("bilibili_*.csv"))
                  if "comment" not in f.name and "danmaku" not in f.name]
    if not bili_files:
        print("未找到B站视频数据！")
        exit(1)

    latest = bili_files[-1]
    print(f"视频数据: {latest}")

    crawler = BilibiliDanmakuCrawler()
    df = crawler.crawl(str(latest))
    print(f"\n采集完成！共 {len(df)} 条弹幕")
