"""
B站搜索爬虫 - 基于requests
调用B站搜索API，采集视频+弹幕+评论

使用方式:
1. 浏览器登录 bilibili.com
2. F12 -> Network -> 复制Cookie到 configs/cookie.txt（可复用微博Cookie文件中的B站Cookie）
   或单独放 configs/bilibili_cookie.txt
3. 运行: python crawler/bilibili_requests.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import requests
import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class BilibiliCrawler:
    """B站搜索爬虫 - 采集视频信息+评论"""

    def __init__(self, cookie: str = ""):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
            "Cookie": cookie,
            "Referer": "https://search.bilibili.com/",
            "Accept": "application/json, text/plain, */*",
        })
        cfg = PLATFORM_CONFIG["bilibili"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

    def search_videos(self, keyword: str, page: int = 1) -> dict:
        """搜索B站视频"""
        url = "https://api.bilibili.com/x/web-interface/search/type"
        params = {
            "search_type": "video",
            "keyword": keyword,
            "page": page,
            "order": "pubdate",  # 按最新排序，覆盖更多时间范围
        }
        try:
            resp = self.session.get(url, params=params, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {}

    def parse_videos(self, data: dict, keyword: str) -> list:
        """解析搜索结果"""
        videos = []
        if not data or data.get("code") != 0:
            return videos

        results = data.get("data", {}).get("result", [])
        for v in results:
            # 清理HTML标签
            title = re.sub(r"<[^>]+>", "", v.get("title", ""))
            description = re.sub(r"<[^>]+>", "", v.get("description", ""))

            if not title and not description:
                continue

            videos.append({
                "id": str(v.get("bvid", "")),
                "aid": str(v.get("aid", "")),
                "text": f"{title} {description}".strip(),
                "title": title,
                "description": description,
                "tag": v.get("tag", ""),
                "user_name": v.get("author", ""),
                "user_mid": str(v.get("mid", "")),
                "play_count": v.get("play", 0),
                "danmaku_count": v.get("video_review", 0),
                "reply_count": v.get("review", 0),
                "favorite_count": v.get("favorites", 0),
                "like_count": v.get("like", 0),
                "pubdate": v.get("pubdate", 0),
                "keyword": keyword,
                "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "platform": "bilibili",
            })
        return videos

    def get_comments(self, aid: str, page: int = 1) -> list:
        """获取视频评论"""
        url = "https://api.bilibili.com/x/v2/reply"
        params = {
            "oid": aid,
            "type": 1,
            "pn": page,
            "ps": 20,
            "order": "time",
        }
        try:
            resp = self.session.get(url, params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
            if data.get("code") != 0:
                return []
            replies = data.get("data", {}).get("replies", [])
            comments = []
            for r in replies:
                content = r.get("content", {}).get("message", "")
                if content and len(content) >= 5:
                    comments.append({
                        "text": content,
                        "user_name": r.get("member", {}).get("uname", ""),
                        "like_count": r.get("like", 0),
                        "reply_count": r.get("rcount", 0),
                    })
            return comments
        except:
            return []

    def crawl_keyword(self, keyword: str, max_pages: int = 8) -> list:
        """搜索单个关键词，采集视频信息"""
        all_videos = []
        for page in range(1, max_pages + 1):
            data = self.search_videos(keyword, page)
            videos = self.parse_videos(data, keyword)
            if not videos:
                break
            all_videos.extend(videos)
            delay = random.uniform(self.delay_min, self.delay_max)
            time.sleep(delay)
        return all_videos

    def crawl(self, keywords: list = None, max_pages: int = 8) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        for kw in tqdm(keywords, desc="B站关键词"):
            videos = self.crawl_keyword(kw, max_pages)
            all_data.extend(videos)
            print(f"  [{kw}] 采集{len(videos)}条，累计{len(all_data)}条")

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"bilibili_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df


def load_cookie() -> str:
    """加载B站Cookie（优先用独立文件，否则用通用Cookie文件）"""
    cookie_file = PROJECT_ROOT / "configs" / "bilibili_cookie.txt"
    if cookie_file.exists():
        cookie = cookie_file.read_text().strip()
        if cookie and not cookie.startswith("#"):
            return cookie
    return ""  # B站搜索不登录也能用，返回空字符串


if __name__ == "__main__":
    print("=" * 60)
    print("  B站搜索爬虫 - 全量采集")
    print("=" * 60)

    cookie = load_cookie()
    crawler = BilibiliCrawler(cookie)
    cfg = PLATFORM_CONFIG["bilibili"]

    print(f"\n关键词数: {len(ALL_KEYWORDS)}")
    print(f"每词最大页数: {cfg['max_pages']}")
    print(f"预估数据量: {len(ALL_KEYWORDS) * cfg['max_pages'] * 20} 条（去重前）")

    df = crawler.crawl(
        keywords=ALL_KEYWORDS,
        max_pages=cfg["max_pages"]
    )

    print(f"\n{'='*60}")
    print(f"采集完成！共 {len(df)} 条")
