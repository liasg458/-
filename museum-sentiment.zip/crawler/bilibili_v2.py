"""B站第二轮扩充 - 后50个博物馆×情感词 + 事件×品类"""
import json, os, re, sys, time, random
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests, pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords_combo import MUSEUMS

def gen_keywords():
    museums_2 = MUSEUMS[50:]
    emotions = ['好看','翻车','质量','贵','推荐','避雷','吐槽','抄袭','争议','黄牛',
                '失望','可爱','惊艳','开箱','测评','种草','踩雷','买','断货','限量']
    combos = []
    for m in museums_2:
        for e in emotions:
            combos.append(f'{m}文创{e}')
            combos.append(f'{m}{e}')
    events = ['凤冠冰箱贴','故宫口红','三星堆盲盒','敦煌文创','博物馆雪糕',
              '文创冰箱贴','博物馆周边','文创联名','文博文创','国潮文创',
              '博物馆文创','故宫文创','国博文创','三星堆文创']
    for e in events:
        for e2 in ['质量','价格','好看','翻车','推荐','吐槽','贵','便宜','买','开箱','测评','避雷']:
            combos.append(f'{e}{e2}')
    return list(dict.fromkeys(combos))

class BiliV2Crawler:
    def __init__(self, num_threads=10):
        self.save_dir = Path("data/raw/bilibili")
        self.headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
                        "Referer": "https://search.bilibili.com/", "Accept": "application/json"}
        self.num_threads = num_threads

    def search_single(self, keyword):
        url = "https://api.bilibili.com/x/web-interface/search/type"
        results = []
        for page in range(1, 6):
            params = {"search_type": "video", "keyword": keyword, "page": page, "order": "pubdate"}
            try:
                resp = requests.get(url, params=params, headers=self.headers, timeout=10)
                data = resp.json()
                items = data.get("data", {}).get("result", [])
                if not items: break
                for v in items:
                    title = re.sub(r"<[^>]+>", "", v.get("title", ""))
                    desc = re.sub(r"<[^>]+>", "", v.get("description", ""))
                    text = f"{title} {desc}".strip()
                    if text and len(text) >= 5:
                        results.append({"id": str(v.get("bvid","")), "text": text, "title": title,
                            "description": desc, "user_name": v.get("author",""),
                            "play_count": v.get("play",0), "reply_count": v.get("review",0),
                            "keyword": keyword, "platform": "bilibili"})
                time.sleep(random.uniform(0.3, 0.8))
            except: break
        return keyword, results

    def crawl(self):
        keywords = gen_keywords()
        print(f"关键词: {len(keywords)}, 线程: {self.num_threads}")
        all_data, ts = [], datetime.now().strftime("%Y%m%d_%H%M%S")
        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = {executor.submit(self.search_single, kw): kw for kw in keywords}
            pbar = tqdm(total=len(futures), desc="B站V2")
            for future in as_completed(futures):
                kw, items = future.result()
                all_data.extend(items)
                pbar.update(1)
                if items: pbar.write(f"  [{kw}] {len(items)}条，累计{len(all_data)}条")
                if len(all_data) % 2000 < 10 and all_data:
                    pd.DataFrame(all_data).drop_duplicates(subset=["id"]).to_csv(
                        self.save_dir / f"bilibili_v2_partial_{ts}.csv", index=False, encoding="utf-8-sig")
            pbar.close()
        df = pd.DataFrame(all_data)
        if not df.empty: df = df.drop_duplicates(subset=["id"])
        f = self.save_dir / f"bilibili_v2_{ts}.csv"
        df.to_csv(f, index=False, encoding="utf-8-sig")
        print(f"保存: {f} ({len(df)}条)")
        return df

if __name__ == "__main__":
    c = BiliV2Crawler(10)
    df = c.crawl()
    print(f"完成！{len(df)}条")
