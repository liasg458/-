"""
微博组合关键词搜索 - 多线程并行
用7260个组合关键词搜索微博，10线程并行

使用方式: python crawler/weibo_combo.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords_combo import generate_combos


class WeiboComboCrawler:
    """微博组合关键词搜索 - 多线程"""

    def __init__(self, cookie: str, num_threads: int = 10):
        self.cookie = cookie
        self.num_threads = num_threads
        self.save_dir = Path("data/raw/weibo")
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.session_pool = []

        # 创建多个session
        for _ in range(num_threads):
            s = requests.Session()
            s.headers.update({
                "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                              "AppleWebKit/605.1.15 (KHTML, like Gecko) "
                              "Version/17.0 Mobile/15E148 Safari/604.1",
                "Cookie": cookie,
                "Referer": "https://m.weibo.cn/",
                "Accept": "application/json, text/plain, */*",
                "X-Requested-With": "XMLHttpRequest",
            })
            self.session_pool.append(s)

    def search_single(self, session, keyword):
        """搜索单个关键词"""
        url = "https://m.weibo.cn/api/container/getIndex"
        params = {
            "containerid": f"100103type=1&q={keyword}",
            "page_type": "searchall",
            "page": 1,
        }
        weibos = []
        try:
            resp = session.get(url, params=params, timeout=10)
            data = resp.json()
            cards = data.get("data", {}).get("cards", [])
            for card in cards:
                if card.get("card_type") != 9:
                    continue
                mblog = card.get("mblog", {})
                if not mblog:
                    continue
                raw_text = mblog.get("text", "")
                clean_text = re.sub(r"<[^>]+>", "", raw_text)
                clean_text = clean_text.replace("\n", " ").strip()
                if not clean_text or len(clean_text) < 5:
                    continue
                weibos.append({
                    "id": str(mblog.get("id", "")),
                    "mid": str(mblog.get("mid", "")),
                    "text": clean_text,
                    "raw_text": raw_text,
                    "user_id": str(mblog.get("user", {}).get("id", "")),
                    "user_name": mblog.get("user", {}).get("screen_name", ""),
                    "created_at": mblog.get("created_at", ""),
                    "source": mblog.get("source", ""),
                    "reposts_count": mblog.get("reposts_count", 0),
                    "comments_count": mblog.get("comments_count", 0),
                    "attitudes_count": mblog.get("attitudes_count", 0),
                    "keyword": keyword,
                    "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "platform": "weibo",
                })
        except:
            pass
        return keyword, weibos

    def crawl(self, keywords=None, max_keywords=None):
        if keywords is None:
            keywords = generate_combos()
        if max_keywords:
            keywords = keywords[:max_keywords]

        print(f"关键词数: {len(keywords)}")
        print(f"并行线程: {self.num_threads}")

        all_data = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        completed = 0

        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = {}
            for i, kw in enumerate(keywords):
                session = self.session_pool[i % self.num_threads]
                future = executor.submit(self.search_single, session, kw)
                futures[future] = kw

            pbar = tqdm(total=len(futures), desc="微博组合搜索")
            for future in as_completed(futures):
                keyword, weibos = future.result()
                all_data.extend(weibos)
                completed += 1
                pbar.update(1)

                if weibos:
                    pbar.write(f"  [{keyword}] {len(weibos)}条，累计{len(all_data)}条")

                # 每500个关键词保存一次
                if completed % 500 == 0 and all_data:
                    tmp_df = pd.DataFrame(all_data).drop_duplicates(subset=["id"])
                    tmp_file = self.save_dir / f"weibo_combo_partial_{timestamp}.csv"
                    tmp_df.to_csv(tmp_file, index=False, encoding="utf-8-sig")
                    pbar.write(f"  临时保存: {len(tmp_df)}条")

            pbar.close()

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            print(f"去重: {before} -> {after}条")

        filename = self.save_dir / f"weibo_combo_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df


def load_cookie():
    cookie_file = PROJECT_ROOT / "configs" / "cookie.txt"
    if not cookie_file.exists():
        return ""
    return cookie_file.read_text().strip()


if __name__ == "__main__":
    print("=" * 60)
    print("  微博组合关键词搜索 - 多线程并行")
    print("=" * 60)

    cookie = load_cookie()
    if not cookie:
        print("Cookie为空！")
        exit(1)

    crawler = WeiboComboCrawler(cookie, num_threads=10)
    df = crawler.crawl(max_keywords=None)  # 全部7260个关键词

    print(f"\n{'='*60}")
    print(f"采集完成！共 {len(df)} 条")
