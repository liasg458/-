"""
微博搜索爬虫 - Playwright + 移动端API多页翻页
用Playwright加载Cookie后，直接请求移动端API，翻50页

之前requests版只翻到第1页就空了，是因为requests的Cookie可能不完整。
Playwright浏览器环境下Cookie完整，可以翻更多页。

使用方式: python crawler/weibo_multi_page.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class WeiboMultiPageCrawler:
    """微博搜索爬虫 - Playwright + 移动端API多页"""

    def __init__(self, cookie: str):
        cfg = PLATFORM_CONFIG["weibo"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

        from playwright.sync_api import sync_playwright

        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=True)
        self.context = self.browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                       "AppleWebKit/605.1.15 (KHTML, like Gecko) "
                       "Version/17.0 Mobile/15E148 Safari/604.1",
        )

        # Cookie设置到 .weibo.cn
        cookies = []
        for item in cookie.split(";"):
            item = item.strip()
            if "=" in item:
                name, value = item.split("=", 1)
                cookies.append({
                    "name": name.strip(),
                    "value": value.strip(),
                    "domain": ".weibo.cn",
                    "path": "/",
                })
        self.context.add_cookies(cookies)
        self.page = self.context.new_page()

    def search_keyword(self, keyword: str, max_pages: int = 50) -> list:
        """搜索关键词，翻多页API"""
        collected = []
        seen_ids = set()

        for pg in range(1, max_pages + 1):
            url = f"https://m.weibo.cn/api/container/getIndex?containerid=100103type%3D1%26q%3D{keyword}&page_type=searchall&page={pg}"

            try:
                # 用page.goto访问API，返回JSON
                self.page.goto(url, timeout=15000, wait_until="domcontentloaded")
                time.sleep(random.uniform(0.5, 1.5))

                # 提取JSON内容
                text = self.page.evaluate("() => document.body.innerText")
                if not text:
                    break

                data = json.loads(text)
                cards = data.get("data", {}).get("cards", [])

                if not cards:
                    break

                page_count = 0
                for card in cards:
                    if card.get("card_type") != 9:
                        continue
                    mblog = card.get("mblog", {})
                    if not mblog:
                        continue

                    mid = str(mblog.get("id", ""))
                    if mid in seen_ids:
                        continue
                    seen_ids.add(mid)

                    raw_text = mblog.get("text", "")
                    clean_text = re.sub(r"<[^>]+>", "", raw_text)
                    clean_text = clean_text.replace("\n", " ").strip()

                    if not clean_text or len(clean_text) < 5:
                        continue

                    collected.append({
                        "id": mid,
                        "mid": str(mblog.get("mid", "")),
                        "text": clean_text,
                        "raw_text": raw_text,
                        "user_id": str(mblog.get("user", {}).get("id", "")),
                        "user_name": mblog.get("user", {}).get("screen_name", ""),
                        "created_at": mblog.get("created_at", ""),
                        "source": mblog.get("source", ""),
                        "reposts_count": mblog.get("reposts_count", 0),
                        "comments_count": mblog.get("comments_count", 0),
                        "attitudes_count": mblog.get("attitudes_count", 0),
                        "keyword": keyword,
                        "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "platform": "weibo",
                    })
                    page_count += 1

                if page_count == 0 and pg > 3:
                    break

            except Exception as e:
                if pg == 1:
                    break
                time.sleep(2)

            # 翻页间隔
            time.sleep(random.uniform(1, 3))

        return collected

    def crawl(self, keywords: list = None, max_pages: int = 50) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        for i, kw in enumerate(tqdm(keywords, desc="微博多页搜索")):
            weibos = self.search_keyword(kw, max_pages)
            all_data.extend(weibos)

            if weibos:
                print(f"  [{kw}] {len(weibos)}条，累计{len(all_data)}条")

            # 每10个关键词保存一次
            if (i + 1) % 10 == 0 and all_data:
                tmp_df = pd.DataFrame(all_data).drop_duplicates(subset=["id"])
                tmp_file = self.save_dir / f"weibo_mp_partial_{timestamp}.csv"
                tmp_df.to_csv(tmp_file, index=False, encoding="utf-8-sig")

            # 关键词间隔
            if i < len(keywords) - 1:
                time.sleep(random.uniform(1, 2))

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            print(f"去重: {before} -> {after}条")

        filename = self.save_dir / f"weibo_mp_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df

    def close(self):
        self.browser.close()
        self.playwright.stop()


def load_cookie():
    cookie_file = PROJECT_ROOT / "configs" / "cookie.txt"
    if not cookie_file.exists():
        return ""
    return cookie_file.read_text().strip()


if __name__ == "__main__":
    print("=" * 60)
    print("  微博搜索爬虫 - Playwright + 多页翻页")
    print("=" * 60)

    cookie = load_cookie()
    if not cookie:
        print("Cookie为空！")
        exit(1)

    crawler = WeiboMultiPageCrawler(cookie)
    try:
        print(f"\n关键词数: {len(ALL_KEYWORDS)}")
        print(f"每词最大页数: 50")

        df = crawler.crawl(keywords=ALL_KEYWORDS, max_pages=50)
        print(f"\n{'='*60}")
        print(f"采集完成！共 {len(df)} 条")
    finally:
        crawler.close()
