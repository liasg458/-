"""
微博PC端搜索爬虫 - Playwright版
访问 s.weibo.cn 搜索页面，翻页采集，每个关键词可获500+条

使用方式: python crawler/weibo_pc.py
需要 configs/cookie.txt 中有微博Cookie
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class WeiboPCCrawler:
    """微博PC端搜索爬虫"""

    def __init__(self, cookie: str):
        cfg = PLATFORM_CONFIG["weibo"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

        from playwright.sync_api import sync_playwright

        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=True)
        self.context = self.browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36",
        )

        # 设置Cookie（s.weibo.cn 域名）
        cookies = []
        for item in cookie.split(";"):
            item = item.strip()
            if "=" in item:
                name, value = item.split("=", 1)
                cookies.append({
                    "name": name.strip(),
                    "value": value.strip(),
                    "domain": ".weibo.com",
                    "path": "/",
                })
        self.context.add_cookies(cookies)
        self.page = self.context.new_page()

    def search_keyword(self, keyword: str, max_pages: int = 50) -> list:
        """搜索关键词，翻页采集"""
        collected = []
        page = self.page
        seen_ids = set()

        for pg in range(1, max_pages + 1):
            url = f"https://s.weibo.cn/weibo?q={keyword}&page={pg}"
            try:
                page.goto(url, timeout=15000, wait_until="domcontentloaded")
                time.sleep(random.uniform(1, 2))

                # 从页面DOM提取微博
                content = page.content()

                # PC端微博搜索结果在 card-wrap 中
                results = page.evaluate("""
                    () => {
                        const weibos = [];
                        const cards = document.querySelectorAll('div.card-wrap[action-type="feed_list_item"]');
                        if (cards.length === 0) {
                            // 尝试其他选择器
                            const altCards = document.querySelectorAll('div[node-type="feed_list_item"]');
                            altCards.forEach(card => {
                                const mid = card.getAttribute('mid') || '';
                                const textEl = card.querySelector('p.txt[node-type="feed_list_content"]') ||
                                              card.querySelector('p.txt') ||
                                              card.querySelector('.content');
                                const text = textEl ? textEl.innerText.trim() : '';

                                const userEl = card.querySelector('a.name') || card.querySelector('.name');
                                const user = userEl ? userEl.innerText.trim() : '';

                                // 互动数据
                                const info = card.querySelector('.card-act') || card.querySelector('.act-info');
                                const infoText = info ? info.innerText : '';

                                if (text && text.length > 5) {
                                    weibos.push({
                                        mid: mid,
                                        text: text.substring(0, 500),
                                        user: user,
                                        info: infoText,
                                    });
                                }
                            });
                        } else {
                            cards.forEach(card => {
                                const mid = card.getAttribute('mid') || '';
                                const textEl = card.querySelector('p.txt[node-type="feed_list_content"]') ||
                                              card.querySelector('p.txt') ||
                                              card.querySelector('.content');
                                const text = textEl ? textEl.innerText.trim() : '';

                                const userEl = card.querySelector('a.name') || card.querySelector('.name');
                                const user = userEl ? userEl.innerText.trim() : '';

                                const info = card.querySelector('.card-act') || card.querySelector('.act-info');
                                const infoText = info ? info.innerText : '';

                                if (text && text.length > 5) {
                                    weibos.push({
                                        mid: mid,
                                        text: text.substring(0, 500),
                                        user: user,
                                        info: infoText,
                                    });
                                }
                            });
                        }
                        return weibos;
                    }
                """)

                if not results:
                    # 检查是否需要登录
                    if "登录" in content and "扫码" in content:
                        print(f"  第{pg}页: 需要登录，Cookie可能过期")
                        break
                    # 检查是否到了最后一页
                    if "没有找到" in content or pg > 5 and len(results) == 0:
                        break
                    break

                for item in results:
                    mid = item.get("mid", f"{keyword}_{pg}_{len(collected)}")
                    if mid in seen_ids:
                        continue
                    seen_ids.add(mid)

                    text = item.get("text", "").strip()
                    if not text or len(text) < 5:
                        continue

                    # 解析互动数据
                    info_text = item.get("info", "")
                    reposts = re.search(r'转发\s*(\d+)', info_text)
                    comments = re.search(r'评论\s*(\d+)', info_text)
                    likes = re.search(r'赞\s*(\d+)', info_text)

                    collected.append({
                        "id": str(mid),
                        "mid": str(mid),
                        "text": text,
                        "raw_text": text,
                        "user_id": "",
                        "user_name": item.get("user", ""),
                        "created_at": "",
                        "source": "",
                        "reposts_count": int(reposts.group(1)) if reposts else 0,
                        "comments_count": int(comments.group(1)) if comments else 0,
                        "attitudes_count": int(likes.group(1)) if likes else 0,
                        "keyword": keyword,
                        "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "platform": "weibo",
                    })

                # 每页间隔
                time.sleep(random.uniform(self.delay_min, self.delay_max))

            except Exception as e:
                print(f"  第{pg}页出错: {str(e)[:50]}")
                if pg == 1:
                    break
                time.sleep(2)

        return collected

    def crawl(self, keywords: list = None, max_pages: int = 50) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        for i, kw in enumerate(tqdm(keywords, desc="微博PC搜索")):
            weibos = self.search_keyword(kw, max_pages)
            all_data.extend(weibos)
            print(f"  [{kw}] 采集{len(weibos)}条，累计{len(all_data)}条")

            # 每10个关键词保存一次
            if (i + 1) % 10 == 0 and all_data:
                tmp_df = pd.DataFrame(all_data).drop_duplicates(subset=["id"])
                tmp_file = self.save_dir / f"weibo_pc_partial_{timestamp}.csv"
                tmp_df.to_csv(tmp_file, index=False, encoding="utf-8-sig")
                print(f"  临时保存: {len(tmp_df)}条")

            # 关键词间隔
            if i < len(keywords) - 1:
                time.sleep(random.uniform(1, 3))

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            print(f"去重: {before} -> {after}条")

        filename = self.save_dir / f"weibo_pc_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df

    def close(self):
        self.browser.close()
        self.playwright.stop()


def load_cookie():
    cookie_file = PROJECT_ROOT / "configs" / "cookie.txt"
    if not cookie_file.exists():
        return ""
    return cookie_file.read_text().strip()


if __name__ == "__main__":
    print("=" * 60)
    print("  微博PC端搜索爬虫 - Playwright")
    print("=" * 60)

    cookie = load_cookie()
    if not cookie:
        print("Cookie为空！")
        exit(1)

    crawler = WeiboPCCrawler(cookie)
    try:
        print(f"\n关键词数: {len(ALL_KEYWORDS)}")
        print(f"每词最大页数: 50")
        print(f"预估每词: 50-500条")
        print(f"预估总量: {len(ALL_KEYWORDS) * 100}条")

        df = crawler.crawl(keywords=ALL_KEYWORDS, max_pages=50)
        print(f"\n{'='*60}")
        print(f"采集完成！共 {len(df)} 条")
    finally:
        crawler.close()
