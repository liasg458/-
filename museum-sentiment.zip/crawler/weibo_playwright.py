"""
微博搜索爬虫 - Playwright版 (headless模式)
用浏览器自动化模拟真人搜索，突破API翻页限制

使用方式:
1. configs/cookie.txt 中有微博Cookie
2. 运行: python crawler/weibo_playwright.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class WeiboPlaywrightCrawler:
    """微博搜索爬虫 - Playwright浏览器自动化"""

    def __init__(self, cookie: str):
        from playwright.sync_api import sync_playwright

        self.cookie_str = cookie
        cfg = PLATFORM_CONFIG["weibo"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=True)
        self.context = self.browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                       "AppleWebKit/605.1.15 (KHTML, like Gecko) "
                       "Version/17.0 Mobile/15E148 Safari/604.1",
        )

        cookies = self._parse_cookie_string(cookie)
        self.context.add_cookies(cookies)
        self.page = self.context.new_page()
        self._collected = []

    def _parse_cookie_string(self, cookie_str: str) -> list:
        cookies = []
        for item in cookie_str.split(";"):
            item = item.strip()
            if "=" in item:
                name, value = item.split("=", 1)
                cookies.append({
                    "name": name.strip(),
                    "value": value.strip(),
                    "domain": ".weibo.cn",
                    "path": "/",
                })
        return cookies

    def search_keyword(self, keyword: str, max_pages: int = 10) -> list:
        """搜索关键词，翻页采集"""
        collected = []
        page = self.page

        def handle_response(response):
            if "getIndex" in response.url and "searchall" in response.url:
                try:
                    data = response.json()
                    cards = data.get("data", {}).get("cards", [])
                    for card in cards:
                        if card.get("card_type") != 9:
                            continue
                        mblog = card.get("mblog", {})
                        if not mblog:
                            continue
                        weibo = self._parse_mblog(mblog, keyword)
                        if weibo:
                            collected.append(weibo)
                except:
                    pass

        page.on("response", handle_response)

        for pg in range(1, max_pages + 1):
            url = f"https://m.weibo.cn/api/container/getIndex?containerid=100103type%3D1%26q%3D{keyword}&page_type=searchall&page={pg}"
            try:
                page.goto(url, timeout=15000)
                time.sleep(random.uniform(self.delay_min, self.delay_max))
            except:
                break

        page.remove_listener("response", handle_response)

        # 去重
        seen_ids = set()
        unique = []
        for w in collected:
            if w["id"] not in seen_ids:
                seen_ids.add(w["id"])
                unique.append(w)
        return unique

    def _parse_mblog(self, mblog: dict, keyword: str) -> dict:
        try:
            raw_text = mblog.get("text", "")
            clean_text = re.sub(r"<[^>]+>", "", raw_text)
            clean_text = clean_text.replace("\n", " ").strip()
            if not clean_text or len(clean_text) < 5:
                return None
            return {
                "id": str(mblog.get("id", "")),
                "mid": str(mblog.get("mid", "")),
                "text": clean_text,
                "raw_text": raw_text,
                "user_id": str(mblog.get("user", {}).get("id", "")),
                "user_name": mblog.get("user", {}).get("screen_name", ""),
                "created_at": mblog.get("created_at", ""),
                "source": mblog.get("source", ""),
                "reposts_count": mblog.get("reposts_count", 0),
                "comments_count": mblog.get("comments_count", 0),
                "attitudes_count": mblog.get("attitudes_count", 0),
                "keyword": keyword,
                "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "platform": "weibo",
            }
        except:
            return None

    def crawl(self, keywords: list = None, max_pages: int = 10) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        for kw in tqdm(keywords, desc="微博Playwright"):
            weibos = self.search_keyword(kw, max_pages)
            all_data.extend(weibos)
            print(f"  [{kw}] 采集{len(weibos)}条，累计{len(all_data)}条")

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"weibo_pw_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df

    def close(self):
        self.browser.close()
        self.playwright.stop()


def load_cookie() -> str:
    cookie_file = PROJECT_ROOT / "configs" / "cookie.txt"
    if not cookie_file.exists():
        return ""
    return cookie_file.read_text().strip()


if __name__ == "__main__":
    print("=" * 60)
    print("  微博搜索爬虫 - Playwright (headless)")
    print("=" * 60)

    cookie = load_cookie()
    if not cookie:
        print("Cookie为空！")
        exit(1)

    crawler = WeiboPlaywrightCrawler(cookie)
    try:
        print(f"\n关键词数: {len(ALL_KEYWORDS)}")
        print(f"每词最大页数: 10")

        df = crawler.crawl(keywords=ALL_KEYWORDS, max_pages=10)
        print(f"\n{'='*60}")
        print(f"采集完成！共 {len(df)} 条")
    finally:
        crawler.close()
