"""
微博搜索爬虫 - 基于requests + Cookie
直接调用微博移动端搜索API

使用方式:
1. 浏览器登录 m.weibo.cn
2. F12 -> Network -> 复制Cookie到 configs/cookie.txt
3. 运行: python crawler/weibo_requests.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import requests
import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class WeiboRequestsCrawler:
    """微博搜索爬虫 - 基于移动端API"""

    def __init__(self, cookie: str):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                          "AppleWebKit/605.1.15 (KHTML, like Gecko) "
                          "Version/17.0 Mobile/15E148 Safari/604.1",
            "Cookie": cookie,
            "Referer": "https://m.weibo.cn/",
            "Accept": "application/json, text/plain, */*",
            "X-Requested-With": "XMLHttpRequest",
        })
        cfg = PLATFORM_CONFIG["weibo"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

    def search(self, keyword: str, page: int = 1) -> dict:
        url = "https://m.weibo.cn/api/container/getIndex"
        params = {
            "containerid": f"100103type=1&q={keyword}",
            "page_type": "searchall",
            "page": page,
        }
        try:
            resp = self.session.get(url, params=params, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {}

    def parse_cards(self, data: dict) -> list:
        weibos = []
        if not data:
            return weibos
        cards = data.get("data", {}).get("cards", [])
        for card in cards:
            if card.get("card_type") != 9:
                continue
            mblog = card.get("mblog", {})
            if not mblog:
                continue
            weibo = self._parse_mblog(mblog)
            if weibo:
                weibos.append(weibo)
        return weibos

    def _parse_mblog(self, mblog: dict) -> dict:
        try:
            raw_text = mblog.get("text", "")
            clean_text = re.sub(r"<[^>]+>", "", raw_text)
            clean_text = clean_text.replace("\n", " ").strip()
            if not clean_text or len(clean_text) < 5:
                return None
            return {
                "id": str(mblog.get("id", "")),
                "mid": str(mblog.get("mid", "")),
                "text": clean_text,
                "raw_text": raw_text,
                "user_id": str(mblog.get("user", {}).get("id", "")),
                "user_name": mblog.get("user", {}).get("screen_name", ""),
                "created_at": mblog.get("created_at", ""),
                "source": mblog.get("source", ""),
                "reposts_count": mblog.get("reposts_count", 0),
                "comments_count": mblog.get("comments_count", 0),
                "attitudes_count": mblog.get("attitudes_count", 0),
                "keyword": "",
                "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "platform": "weibo",
            }
        except:
            return None

    def crawl_keyword(self, keyword: str, max_pages: int = 10) -> list:
        all_weibos = []
        for page in range(1, max_pages + 1):
            data = self.search(keyword, page)
            weibos = self.parse_cards(data)
            if not weibos:
                break
            for w in weibos:
                w["keyword"] = keyword
            all_weibos.extend(weibos)
            delay = random.uniform(self.delay_min, self.delay_max)
            time.sleep(delay)
        return all_weibos

    def crawl(self, keywords: list = None, max_pages: int = 10) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        for kw in tqdm(keywords, desc="微博关键词"):
            weibos = self.crawl_keyword(kw, max_pages)
            all_data.extend(weibos)
            print(f"  [{kw}] 采集{len(weibos)}条，累计{len(all_data)}条")

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"weibo_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df


def load_cookie() -> str:
    cookie_file = PROJECT_ROOT / "configs" / "cookie.txt"
    if not cookie_file.exists():
        return ""
    return cookie_file.read_text().strip()


if __name__ == "__main__":
    print("=" * 60)
    print("  微博搜索爬虫 - 全量采集")
    print("=" * 60)

    cookie = load_cookie()
    if not cookie:
        print("Cookie为空！")
        exit(1)

    crawler = WeiboRequestsCrawler(cookie)
    cfg = PLATFORM_CONFIG["weibo"]

    print(f"\n关键词数: {len(ALL_KEYWORDS)}")
    print(f"每词最大页数: {cfg['max_pages']}")
    print(f"预估数据量: {len(ALL_KEYWORDS) * cfg['max_pages'] * 10} 条（去重前）")

    df = crawler.crawl(
        keywords=ALL_KEYWORDS,
        max_pages=cfg["max_pages"]
    )

    print(f"\n{'='*60}")
    print(f"采集完成！共 {len(df)} 条")
