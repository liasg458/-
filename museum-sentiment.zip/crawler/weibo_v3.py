"""微博V3扩充采集 - 用新的5808个组合关键词"""
import json, os, re, sys, time, random
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests, pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords_v3 import generate_new_combos
from configs.keywords import ALL_KEYWORDS as OLD_KW
from configs.keywords_combo import generate_combos as OLD_COMBOS

def get_new_keywords():
    combos = generate_new_combos()
    old_all = set(OLD_KW + OLD_COMBOS())
    return [c for c in combos if c not in old_all]

class WeiboV3Crawler:
    def __init__(self, cookie, num_threads=10):
        self.cookie = cookie
        self.num_threads = num_threads
        self.save_dir = Path("data/raw/weibo")
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.sessions = []
        for _ in range(num_threads):
            s = requests.Session()
            s.headers.update({
                "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
                "Cookie": cookie, "Referer": "https://m.weibo.cn/",
                "Accept": "application/json", "X-Requested-With": "XMLHttpRequest",
            })
            self.sessions.append(s)

    def search_single(self, session, keyword):
        url = "https://m.weibo.cn/api/container/getIndex"
        params = {"containerid": f"100103type=1&q={keyword}", "page_type": "searchall", "page": 1}
        weibos = []
        try:
            resp = session.get(url, params=params, timeout=10)
            data = resp.json()
            for card in data.get("data", {}).get("cards", []):
                if card.get("card_type") != 9: continue
                mblog = card.get("mblog", {})
                if not mblog: continue
                raw = mblog.get("text", "")
                clean = re.sub(r"<[^>]+>", "", raw).replace("\n", " ").strip()
                if not clean or len(clean) < 5: continue
                weibos.append({
                    "id": str(mblog.get("id", "")), "mid": str(mblog.get("mid", "")),
                    "text": clean, "raw_text": raw,
                    "user_id": str(mblog.get("user", {}).get("id", "")),
                    "user_name": mblog.get("user", {}).get("screen_name", ""),
                    "created_at": mblog.get("created_at", ""),
                    "source": mblog.get("source", ""),
                    "reposts_count": mblog.get("reposts_count", 0),
                    "comments_count": mblog.get("comments_count", 0),
                    "attitudes_count": mblog.get("attitudes_count", 0),
                    "keyword": keyword,
                    "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "platform": "weibo",
                })
        except: pass
        return keyword, weibos

    def crawl(self):
        keywords = get_new_keywords()
        print(f"新关键词: {len(keywords)}, 线程: {self.num_threads}")
        all_data = []
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = {executor.submit(self.search_single, self.sessions[i % self.num_threads], kw): kw
                       for i, kw in enumerate(keywords)}
            pbar = tqdm(total=len(futures), desc="微博V3")
            for future in as_completed(futures):
                kw, items = future.result()
                all_data.extend(items)
                pbar.update(1)
                if items:
                    pbar.write(f"  [{kw}] {len(items)}条，累计{len(all_data)}条")
                if len(all_data) % 500 < 10 and all_data:
                    tmp = pd.DataFrame(all_data).drop_duplicates(subset=["id"])
                    tmp.to_csv(self.save_dir / f"weibo_v3_partial_{ts}.csv", index=False, encoding="utf-8-sig")
            pbar.close()

        df = pd.DataFrame(all_data)
        if not df.empty:
            df = df.drop_duplicates(subset=["id"])
        f = self.save_dir / f"weibo_v3_{ts}.csv"
        df.to_csv(f, index=False, encoding="utf-8-sig")
        print(f"保存: {f} ({len(df)}条)")
        return df

if __name__ == "__main__":
    cookie = open("configs/cookie.txt").read().strip()
    crawler = WeiboV3Crawler(cookie, num_threads=10)
    df = crawler.crawl()
    print(f"完成！共 {len(df)} 条")
