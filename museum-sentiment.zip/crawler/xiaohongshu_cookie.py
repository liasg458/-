"""
小红书搜索爬虫 - Playwright + Cookie
拦截所有API + DOM提取双保险

使用方式: python crawler/xiaohongshu_cookie.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class XiaohongshuCrawler:
    """小红书搜索爬虫 - Cookie + API拦截 + DOM提取"""

    def __init__(self, cookie_str: str):
        cfg = PLATFORM_CONFIG["xiaohongshu"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

        from playwright.sync_api import sync_playwright

        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=True)
        self.context = self.browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36",
        )

        cookies = []
        for item in cookie_str.split(";"):
            item = item.strip()
            if "=" in item:
                name, value = item.split("=", 1)
                cookies.append({
                    "name": name.strip(),
                    "value": value.strip(),
                    "domain": ".xiaohongshu.com",
                    "path": "/",
                })
        self.context.add_cookies(cookies)
        self.page = self.context.new_page()
        self._api_urls = []  # 记录所有API URL用于调试

    def search_keyword(self, keyword: str, max_scrolls: int = 8) -> list:
        """搜索关键词，API拦截 + DOM提取"""
        collected = []
        page = self.page
        self._api_urls = []

        def handle_response(response):
            url = response.url
            # 记录所有xiaohongshu API调用
            if "xiaohongshu.com" in url and response.request.resource_type == "xhr":
                self._api_urls.append(url)

            # 拦截搜索相关API
            if ("search" in url.lower() or "notes" in url.lower()) and "xiaohongshu" in url:
                try:
                    data = response.json()

                    # 尝试多种数据结构
                    items = (
                        data.get("data", {}).get("items", []) or
                        data.get("data", {}).get("data", {}).get("items", []) or
                        data.get("data", {}).get("elements", []) or
                        data.get("items", []) or
                        []
                    )

                    for item in items:
                        note_card = item.get("note_card", {})
                        if not note_card:
                            # 尝试其他结构
                            note_card = item.get("model", {}).get("note_card", {}) if isinstance(item.get("model"), dict) else {}
                        if not note_card:
                            continue

                        note_id = item.get("id", "")
                        display_title = note_card.get("display_title", "")
                        desc = note_card.get("desc", "")
                        user = note_card.get("user", {})
                        user_name = user.get("nickname", user.get("name", ""))
                        interact = note_card.get("interact_info", {})
                        liked_count = interact.get("liked_count", "0")

                        text = f"{display_title} {desc}".strip()
                        if text and len(text) >= 2:
                            collected.append({
                                "id": str(note_id),
                                "text": text,
                                "title": display_title,
                                "description": desc,
                                "user_name": user_name,
                                "like_count": str(liked_count),
                                "keyword": keyword,
                                "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                "platform": "xiaohongshu",
                            })
                except:
                    pass

        page.on("response", handle_response)

        url = f"https://www.xiaohongshu.com/search_result?keyword={keyword}&source=web_search_result_notes"
        try:
            page.goto(url, timeout=20000, wait_until="domcontentloaded")
        except:
            pass
        time.sleep(random.uniform(3, 5))

        # 滚动加载
        for scroll_count in range(max_scrolls):
            try:
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            except:
                pass
            time.sleep(random.uniform(self.delay_min, self.delay_max))

        page.remove_listener("response", handle_response)

        # 如果API没采到，尝试DOM提取
        if not collected:
            dom_notes = self._extract_from_dom(keyword)
            collected.extend(dom_notes)

        # 第一个关键词时打印API URL用于调试
        if self._api_urls:
            print(f"  API URLs: {len(self._api_urls)}个")
            for u in self._api_urls[:3]:
                print(f"    {u[:100]}")

        # 去重
        seen_ids = set()
        unique = []
        for n in collected:
            if n["id"] not in seen_ids:
                seen_ids.add(n["id"])
                unique.append(n)
        return unique

    def _extract_from_dom(self, keyword: str) -> list:
        """从页面DOM提取笔记数据"""
        notes = []
        try:
            result = self.page.evaluate("""
                () => {
                    const notes = [];
                    // 小红书搜索结果在 section.note-item 或 a.cover 中
                    const selectors = [
                        'section.note-item',
                        'div.note-item',
                        'a[class*="cover"]',
                        'div[class*="note-item"]',
                        'div[class*="feeds"] section',
                        'a[href*="/explore/"]',
                        'a[href*="/discovery/item/"]',
                    ];

                    for (const sel of selectors) {
                        const items = document.querySelectorAll(sel);
                        if (items.length > 0) {
                            items.forEach(item => {
                                const text = (item.innerText || item.textContent || '').trim();
                                const href = item.href || item.querySelector('a')?.href || '';
                                if (text && text.length > 2 && !notes.find(n => n.text === text)) {
                                    notes.push({text: text.substring(0, 500), href: href});
                                }
                            });
                            if (notes.length > 0) break;
                        }
                    }
                    return notes;
                }
            """)
            if result:
                for item in result:
                    text = item.get("text", "").strip()
                    href = item.get("href", "")
                    note_id = href.split('/')[-1] if href else f"{keyword}_{len(notes)}"
                    if text and len(text) >= 2:
                        notes.append({
                            "id": str(note_id),
                            "text": text,
                            "title": text.split('\n')[0][:50] if '\n' in text else text[:50],
                            "description": "",
                            "user_name": "",
                            "like_count": "0",
                            "keyword": keyword,
                            "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "platform": "xiaohongshu",
                        })
        except:
            pass
        return notes

    def crawl(self, keywords: list = None, max_scrolls: int = 8) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        for kw in tqdm(keywords, desc="小红书关键词"):
            notes = self.search_keyword(kw, max_scrolls)
            all_data.extend(notes)
            print(f"  [{kw}] 采集{len(notes)}条，累计{len(all_data)}条")

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"xiaohongshu_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df

    def close(self):
        self.browser.close()
        self.playwright.stop()


def load_cookie() -> str:
    cookie_file = PROJECT_ROOT / "configs" / "xhs_cookie.txt"
    if not cookie_file.exists():
        return ""
    return cookie_file.read_text().strip()


if __name__ == "__main__":
    print("=" * 60)
    print("  小红书搜索爬虫 - Cookie + API拦截 + DOM")
    print("=" * 60)

    cookie = load_cookie()
    if not cookie:
        print("Cookie为空！")
        exit(1)

    print(f"Cookie长度: {len(cookie)}字符")

    crawler = XiaohongshuCrawler(cookie)
    try:
        print("\n测试访问小红书首页...")
        crawler.page.goto("https://www.xiaohongshu.com", timeout=20000)
        time.sleep(3)
        title = crawler.page.title()
        print(f"页面标题: {title}")

        # 先测试第一个关键词，看API和DOM情况
        print("\n测试第一个关键词...")
        test_notes = crawler.search_keyword(ALL_KEYWORDS[0], max_scrolls=3)
        print(f"测试结果: {len(test_notes)}条")
        if test_notes:
            print(f"  示例: {test_notes[0]['text'][:80]}")

        if not test_notes:
            print("\n⚠️ 测试未采到数据，打印页面内容用于调试...")
            try:
                content = crawler.page.content()
                print(f"  页面HTML长度: {len(content)}")
                print(f"  包含note-item: {'note-item' in content}")
                print(f"  包含search_result: {'search_result' in content}")
                print(f"  包含login: {'login' in content.lower()}")
            except:
                pass
        else:
            # 正式采集
            cfg = PLATFORM_CONFIG["xiaohongshu"]
            print(f"\n开始正式采集，关键词数: {len(ALL_KEYWORDS)}")
            df = crawler.crawl(keywords=ALL_KEYWORDS, max_scrolls=cfg["max_pages"])
            print(f"\n{'='*60}")
            print(f"采集完成！共 {len(df)} 条")
    finally:
        crawler.close()
