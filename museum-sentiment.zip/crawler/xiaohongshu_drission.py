"""
小红书搜索爬虫 - 基于DrissionPage
使用浏览器自动化方式，模拟用户搜索行为

使用方式:
1. 需要先在Chrome中登录小红书 (xiaohongshu.com)
2. 运行: python crawler/xiaohongshu_drission.py
3. 首次运行会打开Chrome，需要手动登录后按回车继续
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class XiaohongshuCrawler:
    """小红书搜索爬虫 - DrissionPage方案"""

    def __init__(self):
        cfg = PLATFORM_CONFIG["xiaohongshu"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

        from DrissionPage import ChromiumPage, ChromiumOptions

        # 配置浏览器
        co = ChromiumOptions()
        co.headless(False)  # 非无头模式，方便登录
        co.set_argument("--disable-blink-features=AutomationControlled")

        self.page = ChromiumPage(co)
        print("浏览器已启动，正在检测登录状态...")

        # 自动检测登录状态，不依赖input()
        self.page.get("https://www.xiaohongshu.com")
        time.sleep(5)

        # 等待用户登录（最多等120秒）
        print("如果未登录，请在弹出的浏览器中登录小红书...")
        print("已登录的用户将自动继续，最多等待120秒")

        for i in range(24):
            time.sleep(5)
            # 检测是否已登录（页面中有登录后的元素）
            content = self.page.html or ""
            if "登录" in content and "扫码登录" in content:
                # 还在登录页
                if i == 0:
                    print("检测到未登录，请在浏览器中扫码登录...")
                continue
            else:
                # 可能已登录
                print("检测到已登录，开始采集...")
                break
        else:
            print("等待超时，尝试直接采集...")

    def search(self, keyword: str):
        """执行搜索"""
        url = f"https://www.xiaohongshu.com/search_result?keyword={keyword}&source=web_search_result_notes"
        self.page.get(url)
        time.sleep(random.uniform(3, 5))

    def scroll_and_collect(self, max_scrolls: int = 10) -> list:
        """滚动页面收集笔记数据"""
        notes = []
        seen_ids = set()

        for scroll_count in range(max_scrolls):
            # 查找所有笔记卡片
            items = self.page.eles('css:section.note-item')
            if not items:
                # 尝试其他选择器
                items = self.page.eles('css:div.feeds-container section')

            for item in items:
                try:
                    # 提取笔记链接中的ID
                    link = item.attr('href') or ''
                    note_id = link.split('/')[-1] if link else str(len(notes))

                    if note_id in seen_ids:
                        continue
                    seen_ids.add(note_id)

                    # 提取标题
                    title_el = item.ele('css:a.title') or item.ele('css:.title')
                    title = title_el.text.strip() if title_el else ''

                    # 提取作者
                    author_el = item.ele('css:span.name') or item.ele('css:.author')
                    author = author_el.text.strip() if author_el else ''

                    # 提取点赞数
                    like_el = item.ele('css:span.count') or item.ele('css:.like-count')
                    like_count = like_el.text.strip() if like_el else '0'

                    if title:
                        notes.append({
                            "id": note_id,
                            "text": title,
                            "title": title,
                            "user_name": author,
                            "like_count": like_count,
                            "keyword": "",
                            "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "platform": "xiaohongshu",
                        })
                except Exception as e:
                    continue

            # 滚动到底部
            self.page.scroll.down(500)
            time.sleep(random.uniform(self.delay_min, self.delay_max))

        return notes

    def crawl_keyword(self, keyword: str, max_scrolls: int = 8) -> list:
        """搜索单个关键词"""
        self.search(keyword)
        notes = self.scroll_and_collect(max_scrolls)
        for n in notes:
            n["keyword"] = keyword
        return notes

    def crawl(self, keywords: list = None, max_scrolls: int = 8) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        for kw in tqdm(keywords, desc="小红书关键词"):
            notes = self.crawl_keyword(kw, max_scrolls)
            all_data.extend(notes)
            print(f"  [{kw}] 采集{len(notes)}条，累计{len(all_data)}条")

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"xiaohongshu_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df

    def close(self):
        self.page.quit()


if __name__ == "__main__":
    print("=" * 60)
    print("  小红书搜索爬虫 - DrissionPage")
    print("=" * 60)

    crawler = XiaohongshuCrawler()
    cfg = PLATFORM_CONFIG["xiaohongshu"]

    try:
        print(f"\n关键词数: {len(ALL_KEYWORDS)}")
        print(f"每词最大滚动次数: {cfg['max_pages']}")

        df = crawler.crawl(
            keywords=ALL_KEYWORDS,
            max_scrolls=cfg["max_pages"]
        )

        print(f"\n{'='*60}")
        print(f"采集完成！共 {len(df)} 条")
    finally:
        crawler.close()
