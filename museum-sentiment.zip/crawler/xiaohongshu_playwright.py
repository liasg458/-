"""
小红书搜索爬虫 - Playwright DOM提取版
直接从页面DOM提取笔记数据，不依赖API拦截

使用方式: python crawler/xiaohongshu_playwright.py
需要先在弹出的浏览器中登录小红书
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class XiaohongshuCrawler:
    """小红书搜索爬虫 - Playwright DOM提取"""

    def __init__(self):
        cfg = PLATFORM_CONFIG["xiaohongshu"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.delay_min = cfg["delay_min"]
        self.delay_max = cfg["delay_max"]

        from playwright.sync_api import sync_playwright

        self.playwright = sync_playwright().start()
        # 使用持久化上下文，保存登录状态
        self.browser = self.playwright.chromium.launch(headless=False)
        self.context = self.browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36",
        )
        self.page = self.context.new_page()

    def extract_notes_from_dom(self, keyword: str) -> list:
        """直接从DOM提取笔记数据"""
        notes = []
        seen_ids = set()

        # 小红书搜索结果页的笔记选择器（多种可能）
        selectors = [
            'section.note-item',
            'div.note-item',
            'div[class*="note-item"]',
            'a[href*="/explore/"]',
            'a[href*="/discovery/item/"]',
            'div[class*="feeds-container"] section',
        ]

        for selector in selectors:
            try:
                items = self.page.eles(f'css:{selector}') if hasattr(self.page, 'eles') else []
                if not items:
                    items = self.page.query_selector_all(selector)
                if items and len(items) > 0:
                    print(f"  选择器 {selector} 匹配到 {len(items)} 个元素")
                    for item in items:
                        try:
                            # 获取元素文本
                            text_content = ""
                            if hasattr(item, 'text'):
                                text_content = item.text
                            elif hasattr(item, 'text_content'):
                                text_content = item.text_content()
                            else:
                                text_content = item.inner_text() if hasattr(item, 'inner_text') else ""

                            if not text_content or len(text_content) < 2:
                                continue

                            # 获取链接
                            href = ""
                            if hasattr(item, 'get_attribute'):
                                href = item.get_attribute('href') or ''
                            elif hasattr(item, 'attr'):
                                href = item.attr('href') or ''

                            note_id = href.split('/')[-1] if href else f"{keyword}_{len(notes)}"
                            if note_id in seen_ids:
                                continue
                            seen_ids.add(note_id)

                            # 尝试提取标题和作者
                            title = ""
                            author = ""
                            like_count = "0"

                            # 从文本中提取
                            lines = text_content.strip().split('\n')
                            for line in lines:
                                line = line.strip()
                                if not line:
                                    continue
                                if not title and len(line) > 3:
                                    title = line
                                elif '赞' in line or '❤' in line:
                                    like_count = line
                                elif len(line) > 1 and len(line) < 20 and not any(c in line for c in ['赞', '收藏', '评论']):
                                    if not author:
                                        author = line

                            if title:
                                notes.append({
                                    "id": str(note_id),
                                    "text": f"{title} {text_content[:200]}".strip(),
                                    "title": title,
                                    "user_name": author,
                                    "like_count": like_count,
                                    "keyword": keyword,
                                    "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    "platform": "xiaohongshu",
                                })
                        except:
                            continue
                    break  # 找到匹配的选择器就停止
            except:
                continue

        # 也尝试用page.evaluate提取
        if not notes:
            try:
                result = self.page.evaluate("""
                    () => {
                        const notes = [];
                        // 尝试多种选择器
                        const items = document.querySelectorAll('section.note-item, div.note-item, a[href*="/explore/"], div[class*="note"]');
                        items.forEach(item => {
                            const text = item.innerText || item.textContent || '';
                            const href = item.href || item.querySelector('a')?.href || '';
                            if (text && text.length > 2) {
                                notes.push({
                                    text: text.substring(0, 300),
                                    href: href,
                                });
                            }
                        });
                        return notes;
                    }
                """)
                if result:
                    print(f"  page.evaluate提取到 {len(result)} 条")
                    for item in result:
                        text = item.get("text", "").strip()
                        href = item.get("href", "")
                        note_id = href.split('/')[-1] if href else f"{keyword}_{len(notes)}"
                        if note_id in seen_ids:
                            continue
                        seen_ids.add(note_id)
                        if text and len(text) >= 2:
                            notes.append({
                                "id": str(note_id),
                                "text": text,
                                "title": text.split('\n')[0] if '\n' in text else text[:50],
                                "user_name": "",
                                "like_count": "0",
                                "keyword": keyword,
                                "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                "platform": "xiaohongshu",
                            })
            except:
                pass

        return notes

    def search_keyword(self, keyword: str, max_scrolls: int = 8) -> list:
        """搜索关键词并滚动采集"""
        url = f"https://www.xiaohongshu.com/search_result?keyword={keyword}&source=web_search_result_notes"
        try:
            self.page.goto(url, timeout=20000, wait_until="domcontentloaded")
        except:
            pass
        time.sleep(random.uniform(3, 5))

        all_notes = []
        for scroll_count in range(max_scrolls):
            notes = self.extract_notes_from_dom(keyword)
            all_notes.extend(notes)
            self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(random.uniform(self.delay_min, self.delay_max))

        # 去重
        seen_ids = set()
        unique = []
        for n in all_notes:
            if n["id"] not in seen_ids:
                seen_ids.add(n["id"])
                unique.append(n)
        return unique

    def crawl(self, keywords: list = None, max_scrolls: int = 8) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        for kw in tqdm(keywords, desc="小红书关键词"):
            notes = self.search_keyword(kw, max_scrolls)
            all_data.extend(notes)
            print(f"  [{kw}] 采集{len(notes)}条，累计{len(all_data)}条")

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"xiaohongshu_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"保存: {filename} ({len(df)}条)")
        return df

    def close(self):
        self.browser.close()
        self.playwright.stop()


if __name__ == "__main__":
    print("=" * 60)
    print("  小红书搜索爬虫 - Playwright DOM提取版")
    print("=" * 60)

    crawler = XiaohongshuCrawler()
    try:
        # 先访问小红书首页，等待登录
        print("\n正在打开小红书首页，请在浏览器中确认已登录...")
        crawler.page.goto("https://www.xiaohongshu.com", timeout=20000)
        time.sleep(8)

        print("开始采集（如果未登录可能采到空数据）")
        cfg = PLATFORM_CONFIG["xiaohongshu"]
        print(f"关键词数: {len(ALL_KEYWORDS)}")

        df = crawler.crawl(keywords=ALL_KEYWORDS, max_scrolls=cfg["max_pages"])
        print(f"\n{'='*60}")
        print(f"采集完成！共 {len(df)} 条")
    finally:
        crawler.close()
