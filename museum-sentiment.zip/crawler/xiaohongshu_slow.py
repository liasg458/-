"""
小红书搜索爬虫 - 慢速版
降低采集频率避免限流，每个关键词间隔30秒

使用方式: python crawler/xiaohongshu_slow.py
"""

import json
import os
import re
import sys
import time
import random
from pathlib import Path
from datetime import datetime

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.keywords import ALL_KEYWORDS, PLATFORM_CONFIG


class XiaohongshuCrawler:
    """小红书搜索爬虫 - 慢速版避免限流"""

    def __init__(self, cookie_str: str):
        cfg = PLATFORM_CONFIG["xiaohongshu"]
        self.save_dir = Path(cfg["save_dir"])
        self.save_dir.mkdir(parents=True, exist_ok=True)

        from playwright.sync_api import sync_playwright
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=True)
        self.context = self.browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36",
        )

        cookies = []
        for item in cookie_str.split(";"):
            item = item.strip()
            if "=" in item:
                name, value = item.split("=", 1)
                cookies.append({"name": name.strip(), "value": value.strip(), "domain": ".xiaohongshu.com", "path": "/"})
        self.context.add_cookies(cookies)
        self.page = self.context.new_page()

    def search_keyword(self, keyword: str, max_scrolls: int = 5) -> list:
        collected = []
        page = self.page

        def handle_response(response):
            url = response.url
            if ("search" in url.lower() or "notes" in url.lower()) and "xiaohongshu" in url:
                try:
                    data = response.json()
                    items = data.get("data", {}).get("items", []) or data.get("data", {}).get("data", {}).get("items", []) or data.get("items", [])
                    for item in items:
                        note_card = item.get("note_card", {})
                        if not note_card:
                            continue
                        note_id = item.get("id", "")
                        display_title = note_card.get("display_title", "")
                        desc = note_card.get("desc", "")
                        user = note_card.get("user", {})
                        user_name = user.get("nickname", "")
                        interact = note_card.get("interact_info", {})
                        liked_count = interact.get("liked_count", "0")
                        text = f"{display_title} {desc}".strip()
                        if text and len(text) >= 2:
                            collected.append({
                                "id": str(note_id), "text": text, "title": display_title,
                                "description": desc, "user_name": user_name,
                                "like_count": str(liked_count), "keyword": keyword,
                                "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                "platform": "xiaohongshu",
                            })
                except:
                    pass

        page.on("response", handle_response)
        url = f"https://www.xiaohongshu.com/search_result?keyword={keyword}&source=web_search_result_notes"
        try:
            page.goto(url, timeout=20000, wait_until="domcontentloaded")
        except:
            pass
        time.sleep(random.uniform(3, 5))

        for _ in range(max_scrolls):
            try:
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            except:
                pass
            time.sleep(random.uniform(2, 4))

        page.remove_listener("response", handle_response)

        seen_ids = set()
        unique = []
        for n in collected:
            if n["id"] not in seen_ids:
                seen_ids.add(n["id"])
                unique.append(n)
        return unique

    def crawl(self, keywords: list = None, max_scrolls: int = 5) -> pd.DataFrame:
        if keywords is None:
            keywords = ALL_KEYWORDS

        all_data = []
        for i, kw in enumerate(tqdm(keywords, desc="小红书(慢速)")):
            notes = self.search_keyword(kw, max_scrolls)
            all_data.extend(notes)
            print(f"  [{kw}] 采集{len(notes)}条，累计{len(all_data)}条")

            # 每采集5个关键词保存一次（防止中断丢失数据）
            if (i + 1) % 5 == 0 and all_data:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                tmp_file = self.save_dir / f"xiaohongshu_partial_{timestamp}.csv"
                pd.DataFrame(all_data).to_csv(tmp_file, index=False, encoding="utf-8-sig")
                print(f"  临时保存: {tmp_file} ({len(all_data)}条)")

            # 每个关键词之间间隔20-30秒，避免限流
            if i < len(keywords) - 1:
                wait = random.uniform(20, 30)
                print(f"  等待{wait:.0f}秒避免限流...")
                time.sleep(wait)

        df = pd.DataFrame(all_data)
        if not df.empty:
            before = len(df)
            df = df.drop_duplicates(subset=["id"])
            after = len(df)
            if before != after:
                print(f"去重: {before} -> {after}条")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.save_dir / f"xiaohongshu_{timestamp}.csv"
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"最终保存: {filename} ({len(df)}条)")
        return df

    def close(self):
        self.browser.close()
        self.playwright.stop()


def load_cookie() -> str:
    cookie_file = PROJECT_ROOT / "configs" / "xhs_cookie.txt"
    if not cookie_file.exists():
        return ""
    return cookie_file.read_text().strip()


if __name__ == "__main__":
    print("=" * 60)
    print("  小红书搜索爬虫 - 慢速版(防限流)")
    print("=" * 60)

    cookie = load_cookie()
    if not cookie:
        print("Cookie为空！")
        exit(1)

    crawler = XiaohongshuCrawler(cookie)
    try:
        print(f"\n关键词数: {len(ALL_KEYWORDS)}")
        print(f"每词间隔: 20-30秒")
        print(f"预估总时长: {len(ALL_KEYWORDS) * 25 / 60:.0f}分钟")

        df = crawler.crawl(keywords=ALL_KEYWORDS, max_scrolls=5)
        print(f"\n{'='*60}")
        print(f"采集完成！共 {len(df)} 条")
    finally:
        crawler.close()
