# 服务器部署方案

## 1. 环境要求

```bash
# Python 3.10+
python --version

# 创建虚拟环境
python -m venv venv
source venv/bin/activate

# 安装依赖
pip install paddlepaddle-gpu paddlenlp torch transformers
pip install pandas numpy jieba gensim scikit-learn
pip install fastapi uvicorn
```

## 2. 需要上传到服务器的文件

```
museum-sentiment/
├── configs/          # 配置文件
├── crawler/          # 爬虫代码
├── scripts/          # 分析脚本
├── data/labeled/     # 标注后数据
└── models/           # 模型文件
```

## 3. 服务器上执行步骤

```bash
# 1. 训练ERNIE情感分类模型
python scripts/train_ernie.py

# 2. 运行LDA主题聚类
python scripts/lda_topic.py

# 3. 运行情感分析
python scripts/sentiment_ernie.py

# 4. 运行风险识别
python scripts/risk_identify.py

# 5. 启动API服务
python app/backend/main.py
```

## 4. 检查GPU

```bash
nvidia-smi
python -c "import paddle; print(paddle.device.cuda.device_count())"
```
