"""
批量大模型标注 - 用DeepSeek-V3清洗+情感标注
9438条数据，分批处理，每批50条

策略：
  清洗: GLM-4-9B (最快，1.5s/条)
  标注: DeepSeek-V3 (置信度最高)
  投票: 3模型投票（前1000条做投票验证，后面用DeepSeek单模型）

为了效率，先用单模型(DeepSeek-V3)做全量清洗+标注
"""

import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime

import pandas as pd
from openai import OpenAI
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.models import SILICONFLOW_CONFIG, MODELS


def load_api_key():
    key_file = PROJECT_ROOT / "configs" / "api_key.txt"
    return key_file.read_text().strip()


def create_client(api_key):
    return OpenAI(api_key=api_key, base_url=SILICONFLOW_CONFIG["base_url"])


COMBINED_PROMPT = """请对以下社交媒体文本进行分析。文本来自微博/B站，讨论博物馆文创产品。

任务1 - 清洗判断：
- valid=true: 文本与博物馆文创产品相关（设计、质量、价格、文化内涵、购买体验、营销等）
- valid=false: 广告、无关内容、纯符号、无意义文本

任务2 - 情感判断：
- positive: 赞赏、推荐、喜欢、满意
- neutral: 客观描述、询问、分享无明显情感
- negative: 批评、不满、质疑、失望

请返回JSON格式：
{{"valid": true/false, "sentiment": "positive/neutral/negative", "confidence": 0.0-1.0}}

文本：{text}"""


def call_llm(client, model_name, prompt, max_retries=3):
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=256,
            )
            content = response.choices[0].message.content.strip()
            if content.startswith("```"):
                content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
            # 尝试解析JSON
            try:
                return json.loads(content)
            except:
                start = content.find("{")
                end = content.rfind("}") + 1
                if start >= 0 and end > start:
                    return json.loads(content[start:end])
                return {"valid": True, "sentiment": "neutral", "confidence": 0.0}
        except Exception as e:
            if attempt == max_retries - 1:
                return {"valid": True, "sentiment": "neutral", "confidence": 0.0, "error": str(e)[:50]}
            time.sleep(2 ** attempt)
    return {"valid": True, "sentiment": "neutral", "confidence": 0.0}


def main():
    print("=" * 60)
    print("  批量大模型标注 (DeepSeek-V3)")
    print("=" * 60)

    api_key = load_api_key()
    client = create_client(api_key)

    # 读取合并数据
    df = pd.read_csv("data/clean/merged_all.csv")
    print(f"\n总数据量: {len(df)}条")

    # 检查是否已有部分结果
    output_file = Path("data/labeled/all_labeled.csv")
    if output_file.exists():
        existing = pd.read_csv(output_file)
        print(f"已有标注: {len(existing)}条")
        # 合并已有结果
        df = df[~df["text"].isin(existing["text"])]
        print(f"待标注: {len(df)}条")
        if len(df) == 0:
            print("全部已标注完成！")
            return
    else:
        existing = pd.DataFrame()

    # 使用DeepSeek-V3
    model = MODELS["deepseek"]["name"]
    print(f"模型: {model}")

    results = []
    batch_save_interval = 200  # 每200条保存一次

    for i, row in tqdm(df.iterrows(), total=len(df), desc="标注进度"):
        text = str(row["text"])[:500]
        prompt = COMBINED_PROMPT.format(text=text)
        result = call_llm(client, model, prompt)

        results.append({
            "id": row.get("id", ""),
            "text": text,
            "platform": row.get("platform", ""),
            "keyword": row.get("keyword", ""),
            "text_type": row.get("text_type", ""),
            "valid": result.get("valid", True),
            "sentiment": result.get("sentiment", "neutral"),
            "confidence": result.get("confidence", 0.0),
            "error": result.get("error", ""),
        })

        # 定期保存
        if len(results) % batch_save_interval == 0:
            all_results = list(existing.to_dict("records")) + results if not existing.empty else results
            temp_df = pd.DataFrame(all_results)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            temp_df.to_csv(output_file, index=False, encoding="utf-8-sig")
            print(f"\n  已保存 {len(all_results)} 条 ({len(results)}/{len(df)})")

    # 最终保存
    all_results = list(existing.to_dict("records")) + results if not existing.empty else results
    final_df = pd.DataFrame(all_results)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    final_df.to_csv(output_file, index=False, encoding="utf-8-sig")

    print(f"\n{'='*60}")
    print(f"标注完成！共 {len(final_df)} 条")
    print(f"保存: {output_file}")

    # 统计
    valid_count = final_df["valid"].sum()
    print(f"\n有效舆情: {valid_count}/{len(final_df)} ({valid_count/len(final_df)*100:.1f}%)")
    print(f"情感分布: {dict(final_df[final_df['valid']==True]['sentiment'].value_counts())}")


if __name__ == "__main__":
    main()
