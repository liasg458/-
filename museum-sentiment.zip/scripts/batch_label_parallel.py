"""
批量大模型标注 - 多线程并行版
用concurrent.futures并行调用API，10线程并行可提速10倍

9438条 / 10线程 / 2秒每条 ≈ 32分钟
"""

import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
from openai import OpenAI
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.models import SILICONFLOW_CONFIG, MODELS


def load_api_key():
    key_file = PROJECT_ROOT / "configs" / "api_key.txt"
    return key_file.read_text().strip()


def create_client(api_key):
    return OpenAI(api_key=api_key, base_url=SILICONFLOW_CONFIG["base_url"])


COMBINED_PROMPT = """请对以下社交媒体文本进行分析。文本来自微博/B站，讨论博物馆文创产品。

任务1 - 清洗判断：
- valid=true: 文本与博物馆文创产品相关（设计、质量、价格、文化内涵、购买体验、营销等）
- valid=false: 广告、无关内容、纯符号、无意义文本

任务2 - 情感判断：
- positive: 赞赏、推荐、喜欢、满意
- neutral: 客观描述、询问、分享无明显情感
- negative: 批评、不满、质疑、失望

请返回JSON格式：
{{"valid": true/false, "sentiment": "positive/neutral/negative", "confidence": 0.0-1.0}}

文本：{text}"""


def label_single(client, model_name, idx, text, max_retries=3):
    """标注单条文本"""
    prompt = COMBINED_PROMPT.format(text=str(text)[:500])
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=256,
            )
            content = response.choices[0].message.content.strip()
            if content.startswith("```"):
                content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
            try:
                result = json.loads(content)
            except:
                start = content.find("{")
                end = content.rfind("}") + 1
                if start >= 0 and end > start:
                    result = json.loads(content[start:end])
                else:
                    return idx, {"valid": True, "sentiment": "neutral", "confidence": 0.0}
            return idx, result
        except Exception as e:
            if attempt == max_retries - 1:
                return idx, {"valid": True, "sentiment": "neutral", "confidence": 0.0, "error": str(e)[:50]}
            time.sleep(1)
    return idx, {"valid": True, "sentiment": "neutral", "confidence": 0.0}


def main():
    print("=" * 60)
    print("  批量大模型标注 - 多线程并行版")
    print("=" * 60)

    api_key = load_api_key()
    client = create_client(api_key)

    # 读取合并数据
    df = pd.read_csv("data/clean/merged_all.csv")
    print(f"\n总数据量: {len(df)}条")

    # 检查已有结果（断点续传）
    output_file = Path("data/labeled/all_labeled.csv")
    existing_df = None
    if output_file.exists():
        existing_df = pd.read_csv(output_file)
        done_texts = set(existing_df["text"].tolist())
        df = df[~df["text"].isin(done_texts)]
        print(f"已完成: {len(existing_df)}条, 剩余: {len(df)}条")
        if len(df) == 0:
            print("全部已标注完成！")
            return
    else:
        print(f"待标注: {len(df)}条")

    # 使用DeepSeek-V3
    model = MODELS["deepseek"]["name"]
    num_threads = 10  # 10线程并行
    print(f"模型: {model}")
    print(f"并行线程: {num_threads}")
    print(f"预估时间: {len(df) * 2 / num_threads / 60:.0f}分钟")

    # 准备数据
    texts = df["text"].tolist()
    results = [None] * len(texts)
    completed = 0
    save_interval = 500

    # 多线程并行标注
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        # 提交所有任务
        futures = {
            executor.submit(label_single, client, model, i, text): i
            for i, text in enumerate(texts)
        }

        # 进度条
        pbar = tqdm(total=len(futures), desc="并行标注")
        for future in as_completed(futures):
            idx, result = future.result()
            # 防御性处理：确保result是dict
            if not isinstance(result, dict):
                result = {"valid": True, "sentiment": "neutral", "confidence": 0.0}

            results[idx] = {
                "id": str(df.iloc[idx].get("id", "")),
                "text": str(df.iloc[idx].get("text", ""))[:500],
                "platform": df.iloc[idx].get("platform", ""),
                "keyword": str(df.iloc[idx].get("keyword", "")),
                "text_type": df.iloc[idx].get("text_type", ""),
                "valid": result.get("valid", True),
                "sentiment": result.get("sentiment", "neutral"),
                "confidence": result.get("confidence", 0.0),
                "error": result.get("error", ""),
            }
            completed += 1
            pbar.update(1)

            # 定期保存
            if completed % save_interval == 0:
                # 合并已有结果
                new_df = pd.DataFrame([r for r in results if r is not None])
                if existing_df is not None and not existing_df.empty:
                    all_df = pd.concat([existing_df, new_df], ignore_index=True)
                else:
                    all_df = new_df
                output_file.parent.mkdir(parents=True, exist_ok=True)
                all_df.to_csv(output_file, index=False, encoding="utf-8-sig")
                pbar.write(f"  已保存 {len(all_df)} 条 ({completed}/{len(texts)})")

        pbar.close()

    # 最终保存
    new_df = pd.DataFrame([r for r in results if r is not None])
    if existing_df is not None and not existing_df.empty:
        final_df = pd.concat([existing_df, new_df], ignore_index=True)
    else:
        final_df = new_df

    final_df = final_df.drop_duplicates(subset=["text"])
    output_file.parent.mkdir(parents=True, exist_ok=True)
    final_df.to_csv(output_file, index=False, encoding="utf-8-sig")

    print(f"\n{'='*60}")
    print(f"标注完成！共 {len(final_df)} 条")
    print(f"保存: {output_file}")

    # 统计
    valid_count = final_df["valid"].sum()
    print(f"\n有效舆情: {valid_count}/{len(final_df)} ({valid_count/len(final_df)*100:.1f}%)")
    if valid_count > 0:
        valid_df = final_df[final_df["valid"] == True]
        print(f"情感分布: {dict(valid_df['sentiment'].value_counts())}")


if __name__ == "__main__":
    main()
