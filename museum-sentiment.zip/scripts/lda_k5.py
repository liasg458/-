"""LDA主题聚类 - K=5强制版，对齐论文5个风险维度"""
import os, sys, json, re
from pathlib import Path
from collections import Counter
import pandas as pd, numpy as np

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

def load_data():
    labeled_file = Path("data/labeled/all_labeled.csv")
    if labeled_file.exists():
        df = pd.read_csv(labeled_file)
        df = df[df["valid"] == True]
        print(f"有效舆情: {len(df)}条")
    else:
        df = pd.read_csv("data/clean/merged_all.csv")
    df = df[df["text"].str.len() >= 5]
    print(f"过滤后: {len(df)}条")
    return df

def preprocess(text, jieba):
    text = re.sub(r'[^\u4e00-\u9fff\w\s]', '', str(text))
    words = jieba.lcut(text)
    return [w for w in words if len(w) >= 2]

def run_lda():
    import jieba
    from gensim import corpora, models
    from gensim.models import CoherenceModel

    print("=" * 60)
    print("  LDA主题聚类 - K=5（对齐论文风险维度）")
    print("=" * 60)

    df = load_data()

    custom_words = [
        "博物馆文创","文创产品","博物馆周边","故宫文创","国博文创",
        "三星堆文创","敦煌文创","冰箱贴","盲盒","文创雪糕",
        "文创口红","国潮","文创","博物馆","周边","联名",
        "饥饿营销","黄牛","代购","翻车","踩雷","抄袭",
        "凤冠冰箱贴","蝠桃瓶","发簪","兽首","青铜器",
        "文物","文化","历史","设计","质量","价格",
    ]
    for w in custom_words:
        jieba.add_word(w)

    stopwords = set([
        "一个","可以","这个","那个","就是","觉得","真的","什么","没有",
        "不是","还是","怎么","已经","他们","我们","你们","自己","这样",
        "那样","一下","一种","起来","出来","回来","过来","这里","那里",
        "哪里","现在","以前","以后","一直","一般","一定","可能","应该",
        "需要","喜欢","知道","看到","发现","视频","播放","收藏","转发",
        "评论","关注","点赞","http","https","com","www","html","全文","博文",
        "微博","quot","今天","很多","非常","东西","感觉","如果","不会",
        "还有","这种","开始","其实","记得","确实","世界","不要","有些",
        "好看","这么","那么","有点","直接","不能","但是","因为","所以",
        "还是","或者","而且","然后","不过","只有","只是","已经","一下",
        "出来","进去","上来","下来","回来","过来","回去","过去",
    ])

    print("\n正在分词...")
    texts = []
    for text in df["text"]:
        words = preprocess(text, jieba)
        words = [w for w in words if w not in stopwords]
        if words:
            texts.append(words)

    print(f"分词完成: {len(texts)}篇文档")

    dictionary = corpora.Dictionary(texts)
    dictionary.filter_extremes(no_below=5, no_above=0.5)
    corpus = [dictionary.doc2bow(text) for text in texts]
    print(f"词典大小: {len(dictionary)}")

    # 强制K=5
    K = 5
    print(f"\n训练LDA (K={K})...")
    lda = models.LdaModel(
        corpus=corpus, id2word=dictionary, num_topics=K,
        random_state=42, passes=20, alpha="auto", eta="auto",
    )

    cm = CoherenceModel(model=lda, texts=texts, dictionary=dictionary, coherence="c_v")
    coherence = cm.get_coherence()
    print(f"Coherence: {coherence:.4f}")

    print(f"\n{'='*60}")
    print(f"LDA主题聚类结果 (K={K})")
    print(f"{'='*60}")

    topic_data = []
    for idx in range(K):
        words = lda.show_topic(idx, topn=15)
        kw = [w for w, p in words]
        print(f"\n主题{idx}: {', '.join(kw[:10])}")
        topic_data.append({
            "topic_id": idx,
            "keywords": json.dumps(kw, ensure_ascii=False),
            "keywords_str": ", ".join(kw[:10]),
        })

    topic_df = pd.DataFrame(topic_data)
    topic_df.to_csv("analysis/topic/lda_topics_k5.csv", index=False, encoding="utf-8-sig")

    # 文档主题分配
    doc_topics = []
    for i, bow in enumerate(corpus):
        td = lda.get_document_topics(bow)
        if td:
            best = max(td, key=lambda x: x[1])
            doc_topics.append({"doc_id": i, "topic_id": best[0], "topic_prob": best[1]})
        else:
            doc_topics.append({"doc_id": i, "topic_id": -1, "topic_prob": 0})

    doc_df = pd.DataFrame(doc_topics)
    doc_df.to_csv("analysis/topic/doc_topics_k5.csv", index=False, encoding="utf-8-sig")

    print(f"\n主题分布:")
    dist = doc_df["topic_id"].value_counts().sort_index()
    for tid, count in dist.items():
        if tid >= 0:
            kw = topic_df[topic_df["topic_id"]==tid]["keywords_str"].values[0]
            print(f"  主题{tid}: {count}篇 ({count/len(doc_df)*100:.1f}%) - {kw}")

    lda.save("models/lda/lda_model_k5.model")
    dictionary.save("models/lda/dictionary_k5.dict")
    corpora.MmCorpus.serialize("models/lda/corpus_k5.mm", corpus)
    print(f"\n模型已保存")

if __name__ == "__main__":
    run_lda()
