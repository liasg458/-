"""
LDA主题聚类分析
对清洗后的有效舆情数据进行主题聚类

使用方式: python scripts/lda_topic.py
"""

import os
import sys
import json
from pathlib import Path
from collections import Counter

import pandas as pd
import numpy as np

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))


def load_data():
    """加载标注后的数据"""
    labeled_file = Path("data/labeled/all_labeled.csv")
    if labeled_file.exists():
        df = pd.read_csv(labeled_file)
        # 只保留有效舆情
        df = df[df["valid"] == True]
        print(f"有效舆情: {len(df)}条")
    else:
        # 如果没有标注数据，用原始合并数据
        df = pd.read_csv("data/clean/merged_all.csv")
        print(f"使用原始数据: {len(df)}条")

    # 过滤过短文本
    df = df[df["text"].str.len() >= 5]
    print(f"过滤后: {len(df)}条")
    return df


def preprocess_text(text, jieba):
    """中文分词预处理"""
    import re
    # 去除标点和特殊字符
    text = re.sub(r'[^\u4e00-\u9fff\w\s]', '', str(text))
    words = jieba.lcut(text)
    return [w for w in words if len(w) >= 2]


def run_lda():
    """LDA主题聚类"""
    import jieba
    from gensim import corpora, models

    print("=" * 60)
    print("  LDA主题聚类分析")
    print("=" * 60)

    df = load_data()

    # 添加自定义词典
    custom_words = [
        "博物馆文创", "文创产品", "博物馆周边", "故宫文创", "国博文创",
        "三星堆文创", "敦煌文创", "冰箱贴", "盲盒", "文创雪糕",
        "文创口红", "国潮", "文创", "博物馆", "周边", "联名",
        "饥饿营销", "黄牛", "代购", "翻车", "踩雷",
    ]
    for w in custom_words:
        jieba.add_word(w)

    # 停用词
    stopwords = set([
        "一个", "可以", "这个", "那个", "就是", "觉得", "真的",
        "什么", "没有", "不是", "还是", "怎么", "已经", "他们",
        "我们", "你们", "自己", "这样", "那样", "一下", "一种",
        "起来", "出来", "回来", "过来", "这里", "那里", "哪里",
        "现在", "以前", "以后", "一直", "一般", "一定", "可能",
        "应该", "需要", "喜欢", "知道", "觉得", "看到", "发现",
        "视频", "播放", "收藏", "转发", "评论", "关注", "点赞",
        "http", "https", "com", "www", "html",
    ])

    # 分词
    print("\n正在分词...")
    texts = []
    for text in df["text"]:
        words = preprocess_text(text, jieba)
        words = [w for w in words if w not in stopwords]
        if words:
            texts.append(words)

    print(f"分词完成: {len(texts)}篇文档")

    # 构建词典和语料库
    dictionary = corpora.Dictionary(texts)
    dictionary.filter_extremes(no_below=5, no_above=0.5)
    corpus = [dictionary.doc2bow(text) for text in texts]
    print(f"词典大小: {len(dictionary)}")
    print(f"语料库大小: {len(corpus)}")

    # 不同K值训练LDA，选最优
    print("\n搜索最优K值...")
    results = {}
    for k in [5, 8, 10, 12, 15]:
        lda_model = models.LdaModel(
            corpus=corpus,
            id2word=dictionary,
            num_topics=k,
            random_state=42,
            passes=10,
            alpha="auto",
            eta="auto",
        )
        # 计算一致性分数
        from gensim.models import CoherenceModel
        cm = CoherenceModel(model=lda_model, texts=texts, dictionary=dictionary, coherence="c_v")
        coherence = cm.get_coherence()
        results[k] = coherence
        print(f"  K={k}: Coherence={coherence:.4f}")

    # 选最优K
    best_k = max(results, key=results.get)
    print(f"\n最优K值: {best_k} (Coherence={results[best_k]:.4f})")

    # 用最优K训练最终模型
    print(f"\n用K={best_k}训练最终LDA模型...")
    final_lda = models.LdaModel(
        corpus=corpus,
        id2word=dictionary,
        num_topics=best_k,
        random_state=42,
        passes=20,
        alpha="auto",
        eta="auto",
    )

    # 打印每个主题的关键词
    print(f"\n{'='*60}")
    print(f"LDA主题聚类结果 (K={best_k})")
    print(f"{'='*60}")

    topic_data = []
    for idx in range(best_k):
        words = final_lda.show_topic(idx, topn=15)
        topic_keywords = [w for w, p in words]
        print(f"\n主题{idx}: {', '.join(topic_keywords[:10])}")
        topic_data.append({
            "topic_id": idx,
            "keywords": json.dumps(topic_keywords, ensure_ascii=False),
            "keywords_str": ", ".join(topic_keywords[:10]),
        })

    # 保存主题结果
    topic_df = pd.DataFrame(topic_data)
    topic_df.to_csv("analysis/topic/lda_topics.csv", index=False, encoding="utf-8-sig")

    # 为每条文档分配主题
    print(f"\n为文档分配主题...")
    doc_topics = []
    for i, bow in enumerate(corpus):
        topic_dist = final_lda.get_document_topics(bow)
        if topic_dist:
            best_topic = max(topic_dist, key=lambda x: x[1])
            doc_topics.append({
                "doc_id": i,
                "topic_id": best_topic[0],
                "topic_prob": best_topic[1],
            })
        else:
            doc_topics.append({"doc_id": i, "topic_id": -1, "topic_prob": 0})

    doc_topic_df = pd.DataFrame(doc_topics)
    doc_topic_df.to_csv("analysis/topic/doc_topics.csv", index=False, encoding="utf-8-sig")

    # 主题分布统计
    print(f"\n主题分布:")
    topic_dist = doc_topic_df["topic_id"].value_counts().sort_index()
    for tid, count in topic_dist.items():
        if tid >= 0:
            keywords = topic_df[topic_df["topic_id"] == tid]["keywords_str"].values[0]
            print(f"  主题{tid}: {count}篇 ({count/len(doc_topic_df)*100:.1f}%) - {keywords}")

    # 保存模型
    final_lda.save("models/lda/lda_model.model")
    dictionary.save("models/lda/dictionary.dict")
    corpus = [dictionary.doc2bow(text) for text in texts]
    corpora.MmCorpus.serialize("models/lda/corpus.mm", corpus)

    print(f"\n模型已保存到 models/lda/")
    print(f"主题结果已保存到 analysis/topic/")

    return final_lda, dictionary, topic_df


if __name__ == "__main__":
    lda_model, dictionary, topic_df = run_lda()
