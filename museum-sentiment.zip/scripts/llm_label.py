"""
大模型多模型数据清洗 + 情感标注对比工具

功能：
1. 用多个大模型对文本进行清洗（判断是否有效舆情）
2. 用多个大模型对文本进行情感标注（正/中/负）
3. 用多个大模型对文本进行方面级情感标注
4. 多模型投票机制
5. 与人工标注结果对比评估

使用方式:
1. 在 configs/api_key.txt 中填入硅基流动API Key
2. 准备待标注数据到 data/raw/ 目录
3. 运行: python scripts/llm_label.py
"""

import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime

import pandas as pd
from openai import OpenAI
from tqdm import tqdm

# 项目根目录
PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from configs.models import SILICONFLOW_CONFIG, MODELS, LABEL_CONFIG


def load_api_key() -> str:
    """加载API Key"""
    key_file = PROJECT_ROOT / "configs" / "api_key.txt"
    if not key_file.exists():
        print(f"请创建 {key_file} 并填入硅基流动API Key")
        print("注册地址: https://cloud.siliconflow.cn/")
        return ""
    key = key_file.read_text().strip()
    if not key:
        print("API Key文件为空！")
    return key


def create_client(api_key: str) -> OpenAI:
    """创建SiliconFlow API客户端"""
    return OpenAI(
        api_key=api_key,
        base_url=SILICONFLOW_CONFIG["base_url"],
    )


# ============================================================
#  Prompt模板
# ============================================================

CLEAN_PROMPT = """你是一个数据清洗助手。请判断以下社交媒体文本是否与博物馆文创产品的舆情相关。

判断标准：
- is_valid=true: 文本讨论了博物馆文创产品（设计、质量、价格、文化内涵、购买体验、营销等）
- is_valid=false: 广告推广、无关内容、纯转发无观点、过短无意义

请返回JSON格式：
{{"is_valid": true/false, "text_type": "opinion/advertisement/spam/irrelevant", "reason": "简要原因"}}

文本：{text}"""

SENTIMENT_PROMPT = """请对以下社交媒体文本进行情感分析。文本来自微博/小红书等平台，讨论博物馆文创产品。

判断标准：
- positive: 赞赏、推荐、喜欢、期待、满意
- neutral: 客观描述、询问、分享无明显情感倾向
- negative: 批评、不满、质疑、担忧、愤怒、失望

请返回JSON格式：
{{"sentiment": "positive/neutral/negative", "confidence": 0.0-1.0, "key_phrases": ["影响判断的关键短语"]}}

文本：{text}"""

ASPECT_PROMPT = """请对以下文本进行方面级情感分析。文本讨论博物馆文创产品。

方面体系（四维风险）：
- product(产品本体): 质量、价格、做工、材质、实用性等
- culture(文化内容): 设计、文化内涵、创意、符号表达等
- marketing(营销传播): 营销方式、饥饿营销、定价策略、宣传等
- audience(受众认同): 文化认同、消费体验、情感共鸣、价值观等

每条文本可能涉及多个方面，也可能不涉及任何方面。

请返回JSON格式：
{{"aspects": [{{"dimension": "product/culture/marketing/audience", "aspect": "具体方面", "sentiment": "positive/negative/neutral", "evidence": "文本中的证据片段"}}]}}

文本：{text}"""


# ============================================================
#  API调用
# ============================================================

def call_llm(client: OpenAI, model_name: str, prompt: str, max_retries: int = 3) -> dict:
    """调用大模型API"""
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=512,
            )
            content = response.choices[0].message.content.strip()

            # 尝试解析JSON
            # 去除可能的markdown代码块标记
            if content.startswith("```"):
                content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

            return json.loads(content)

        except json.JSONDecodeError:
            # JSON解析失败，尝试提取JSON部分
            try:
                start = content.find("{")
                end = content.rfind("}") + 1
                if start >= 0 and end > start:
                    return json.loads(content[start:end])
            except:
                pass
            if attempt == max_retries - 1:
                return {"error": "JSON parse failed", "raw": content[:200]}
            time.sleep(1)

        except Exception as e:
            if attempt == max_retries - 1:
                return {"error": str(e)}
            time.sleep(2 ** attempt)

    return {"error": "max retries exceeded"}


# ============================================================
#  清洗对比
# ============================================================

def run_cleaning_comparison(texts: list, client: OpenAI) -> pd.DataFrame:
    """
    多模型数据清洗对比
    """
    results = []

    for model_key, model_info in MODELS.items():
        print(f"\n{'='*50}")
        print(f"清洗对比 - 模型: {model_info['label']} ({model_info['name']})")
        print(f"{'='*50}")

        for i, text in enumerate(tqdm(texts, desc=model_info["label"])):
            prompt = CLEAN_PROMPT.format(text=text[:500])
            result = call_llm(client, model_info["name"], prompt)

            results.append({
                "text_id": i,
                "text": text[:100],
                "model": model_key,
                "model_name": model_info["label"],
                "is_valid": result.get("is_valid", None),
                "text_type": result.get("text_type", None),
                "reason": result.get("reason", ""),
                "error": result.get("error", ""),
            })

    return pd.DataFrame(results)


# ============================================================
#  情感标注对比
# ============================================================

def run_sentiment_comparison(texts: list, client: OpenAI) -> pd.DataFrame:
    """
    多模型情感标注对比
    """
    results = []

    for model_key, model_info in MODELS.items():
        print(f"\n{'='*50}")
        print(f"情感标注 - 模型: {model_info['label']} ({model_info['name']})")
        print(f"{'='*50}")

        for i, text in enumerate(tqdm(texts, desc=model_info["label"])):
            prompt = SENTIMENT_PROMPT.format(text=text[:500])
            result = call_llm(client, model_info["name"], prompt)

            results.append({
                "text_id": i,
                "text": text[:100],
                "model": model_key,
                "model_name": model_info["label"],
                "sentiment": result.get("sentiment", None),
                "confidence": result.get("confidence", None),
                "key_phrases": str(result.get("key_phrases", [])),
                "error": result.get("error", ""),
            })

    return pd.DataFrame(results)


# ============================================================
#  方面级情感标注
# ============================================================

def run_aspect_comparison(texts: list, client: OpenAI) -> pd.DataFrame:
    """
    多模型方面级情感标注对比
    """
    results = []

    for model_key, model_info in MODELS.items():
        print(f"\n{'='*50}")
        print(f"方面级标注 - 模型: {model_info['label']} ({model_info['name']})")
        print(f"{'='*50}")

        for i, text in enumerate(tqdm(texts, desc=model_info["label"])):
            prompt = ASPECT_PROMPT.format(text=text[:500])
            result = call_llm(client, model_info["name"], prompt)

            results.append({
                "text_id": i,
                "text": text[:100],
                "model": model_key,
                "model_name": model_info["label"],
                "aspects": json.dumps(result.get("aspects", []), ensure_ascii=False),
                "error": result.get("error", ""),
            })

    return pd.DataFrame(results)


# ============================================================
#  多模型投票
# ============================================================

def voting_mechanism(df: pd.DataFrame, label_col: str = "sentiment") -> pd.DataFrame:
    """
    多模型投票机制
    """
    pivot = df.pivot_table(
        index="text_id",
        columns="model",
        values=label_col,
        aggfunc="first"
    )

    # 投票
    vote_result = pivot.mode(axis=1)[0]  # 取多数票
    vote_count = pivot.apply(lambda x: x.value_counts().iloc[0], axis=1)  # 最高票数
    total_models = pivot.notna().sum(axis=1)  # 有效模型数

    result = pd.DataFrame({
        "text_id": pivot.index,
        "vote_label": vote_result.values,
        "vote_count": vote_count.values,
        "total_models": total_models.values,
        "confidence": (vote_count / total_models).values,
    })

    # 标记是否需要人工审核
    result["need_review"] = result["confidence"] < 0.6  # 低于60%一致需要审核

    return result


# ============================================================
#  主流程
# ============================================================

def main():
    print("=" * 60)
    print("  大模型多模型清洗 + 标注对比工具")
    print("  平台: 硅基流动(SiliconFlow)")
    print("=" * 60)

    api_key = load_api_key()
    if not api_key:
        return

    client = create_client(api_key)

    # 检查是否有待标注数据（递归搜索子目录）
    data_dir = PROJECT_ROOT / "data" / "raw"
    csv_files = list(data_dir.rglob("*.csv"))

    if not csv_files:
        print("\n未找到待标注数据！")
        print("请先运行爬虫采集数据: python crawler/weibo_requests.py")
        print("或手动准备数据到 data/raw/ 目录")
        return

    # 读取最新数据
    latest_file = max(csv_files, key=os.path.getctime)
    print(f"\n读取数据: {latest_file}")
    df = pd.read_csv(latest_file)
    texts = df["text"].tolist()

    # 限制测试数量
    test_size = min(50, len(texts))  # 先测50条
    test_texts = texts[:test_size]
    print(f"测试数据量: {test_size}条")

    output_dir = PROJECT_ROOT / "data" / "labeled"
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 1. 清洗对比
    print("\n[1/3] 数据清洗对比...")
    clean_df = run_cleaning_comparison(test_texts, client)
    clean_file = output_dir / f"clean_comparison_{timestamp}.csv"
    clean_df.to_csv(clean_file, index=False, encoding="utf-8-sig")
    print(f"保存: {clean_file}")

    # 2. 情感标注对比
    print("\n[2/3] 情感标注对比...")
    sent_df = run_sentiment_comparison(test_texts, client)
    sent_file = output_dir / f"sentiment_comparison_{timestamp}.csv"
    sent_df.to_csv(sent_file, index=False, encoding="utf-8-sig")
    print(f"保存: {sent_file}")

    # 3. 多模型投票
    print("\n[3/3] 多模型投票...")
    vote_df = voting_mechanism(sent_df)
    vote_file = output_dir / f"voting_result_{timestamp}.csv"
    vote_df.to_csv(vote_file, index=False, encoding="utf-8-sig")
    print(f"保存: {vote_file}")

    # 打印结果摘要
    print(f"\n{'='*60}")
    print("结果摘要:")
    print(f"{'='*60}")

    print("\n[清洗结果] 各模型判断为有效舆情的比例:")
    for model in clean_df["model"].unique():
        subset = clean_df[clean_df["model"] == model]
        valid_ratio = subset["is_valid"].mean()
        print(f"  {model}: {valid_ratio:.1%}")

    print("\n[情感标注] 各模型情感分布:")
    for model in sent_df["model"].unique():
        subset = sent_df[sent_df["model"] == model]
        dist = subset["sentiment"].value_counts()
        print(f"  {model}: {dict(dist)}")

    print("\n[投票结果] 需人工审核比例:")
    review_ratio = vote_df["need_review"].mean()
    print(f"  {review_ratio:.1%} 的数据需要人工审核")

    print("\n完成！请检查输出文件。")


if __name__ == "__main__":
    main()
