"""
合并三平台数据，统一格式，为后续分析做准备
"""

import pandas as pd
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))


def merge_all_data():
    """合并所有平台数据"""
    all_records = []

    # 微博
    weibo_files = list(Path("data/raw/weibo").glob("*.csv"))
    weibo_all = [pd.read_csv(f) for f in weibo_files]
    weibo_df = pd.concat(weibo_all, ignore_index=True).drop_duplicates(subset=["id"])
    for _, row in weibo_df.iterrows():
        text = str(row.get("text", "")).strip()
        if text and len(text) >= 5:
            all_records.append({
                "id": str(row.get("id", "")),
                "text": text,
                "platform": "weibo",
                "user_name": str(row.get("user_name", "")),
                "keyword": str(row.get("keyword", "")),
                "reposts_count": row.get("reposts_count", 0),
                "comments_count": row.get("comments_count", 0),
                "attitudes_count": row.get("attitudes_count", 0),
                "text_type": "post",  # 帖子/评论/弹幕
            })
    print(f"微博: {len(weibo_df)}条")

    # B站视频
    bili_files = [f for f in Path("data/raw/bilibili").glob("bilibili_*.csv")
                  if "comment" not in f.name and "danmaku" not in f.name]
    if bili_files:
        bili_all_dfs = [pd.read_csv(f, engine="python", on_bad_lines="skip") for f in bili_files]
        bili_df = pd.concat(bili_all_dfs, ignore_index=True).drop_duplicates(subset=["id"])
        for _, row in bili_df.iterrows():
            text = str(row.get("text", "")).strip()
            if text and len(text) >= 5:
                all_records.append({
                    "id": str(row.get("id", "")),
                    "text": text,
                    "platform": "bilibili",
                    "user_name": str(row.get("user_name", "")),
                    "keyword": str(row.get("keyword", "")),
                    "reposts_count": 0,
                    "comments_count": row.get("reply_count", 0),
                    "attitudes_count": row.get("like_count", 0),
                    "text_type": "video",
                })
        print(f"B站视频: {len(bili_df)}条")

    # B站弹幕
    dm_files = list(Path("data/raw/bilibili").glob("*danmaku*.csv"))
    if dm_files:
        dm_df = pd.read_csv(dm_files[-1]).drop_duplicates(subset=["text", "video_bvid"])
        for _, row in dm_df.iterrows():
            text = str(row.get("text", "")).strip()
            if text and len(text) >= 2:  # 弹幕可以短一些
                all_records.append({
                    "id": f"dm_{row.get('video_bvid', '')}_{len(all_records)}",
                    "text": text,
                    "platform": "bilibili",
                    "user_name": "",
                    "keyword": str(row.get("keyword", "")),
                    "reposts_count": 0,
                    "comments_count": 0,
                    "attitudes_count": 0,
                    "text_type": "danmaku",
                })
        print(f"B站弹幕: {len(dm_df)}条")

    # 合并
    df = pd.DataFrame(all_records)
    df = df.drop_duplicates(subset=["text"])  # 按文本去重

    # 保存
    save_path = Path("data/clean/merged_all.csv")
    save_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(save_path, index=False, encoding="utf-8-sig")

    print(f"\n合并完成: {len(df)}条 (去重后)")
    print(f"保存: {save_path}")
    print(f"\n平台分布:")
    print(df["platform"].value_counts())
    print(f"\n文本类型分布:")
    print(df["text_type"].value_counts())
    print(f"\n文本长度统计:")
    print(df["text"].str.len().describe())

    return df


if __name__ == "__main__":
    print("=" * 60)
    print("  合并三平台数据")
    print("=" * 60)
    df = merge_all_data()
