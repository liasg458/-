"""
ERNIE情感分类模型训练 - 服务器版
使用PaddleNLP + ERNIE 3.0训练情感三分类模型

在服务器上运行:
  python scripts/train_ernie.py

需要:
  pip install paddlepaddle-gpu paddlenlp
"""

import os
import sys
import json
import random
from pathlib import Path

import pandas as pd
import numpy as np

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))


def prepare_training_data():
    """准备训练数据"""
    df = pd.read_csv("data/labeled/all_labeled.csv")
    valid = df[df["valid"] == True].copy()

    # 情感标签映射
    label_map = {"positive": 2, "neutral": 1, "negative": 0}
    valid["label"] = valid["sentiment"].map(label_map)

    # 只保留有标签的数据
    valid = valid[valid["label"].notna()]

    # 划分训练/验证/测试
    from sklearn.model_selection import train_test_split
    train_df, temp_df = train_test_split(valid, test_size=0.3, random_state=42, stratify=valid["label"])
    dev_df, test_df = train_test_split(temp_df, test_size=0.5, random_state=42, stratify=temp_df["label"])

    print(f"训练集: {len(train_df)}条")
    print(f"验证集: {len(dev_df)}条")
    print(f"测试集: {len(test_df)}条")
    print(f"\n训练集情感分布:\n{train_df['sentiment'].value_counts()}")
    print(f"\n验证集情感分布:\n{dev_df['sentiment'].value_counts()}")

    # 保存为PaddleNLP格式
    train_dir = Path("data/labeled/train")
    train_dir.mkdir(parents=True, exist_ok=True)

    for name, split_df in [("train", train_df), ("dev", dev_df), ("test", test_df)]:
        filepath = train_dir / f"{name}.txt"
        with open(filepath, "w", encoding="utf-8") as f:
            for _, row in split_df.iterrows():
                text = str(row["text"])[:500].replace("\t", " ").replace("\n", " ")
                label = int(row["label"])
                f.write(f"{text}\t{label}\n")
        print(f"保存: {filepath} ({len(split_df)}条)")

    return len(train_df), len(dev_df), len(test_df)


def train_ernie():
    """训练ERNIE模型"""
    import paddle
    from paddlenlp.transformers import ErnieForSequenceClassification, ErnieTokenizer
    from paddlenlp.datasets import load_dataset
    from paddlenlp.trainer import PdArgumentParser, TrainingArguments, Trainer

    # 检查GPU
    print(f"PaddlePaddle版本: {paddle.__version__}")
    print(f"GPU可用: {paddle.device.cuda.device_count() > 0}")

    # 模型配置
    MODEL_NAME = "ernie-3.0-base-zh"
    MAX_SEQ_LENGTH = 128
    BATCH_SIZE = 32
    LEARNING_RATE = 2e-5
    EPOCHS = 5

    # 加载tokenizer
    tokenizer = ErnieTokenizer.from_pretrained(MODEL_NAME)

    # 加载数据
    def read_dataset(filepath):
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                text, label = line.strip().rsplit("\t", 1)
                yield {"text": text, "label": int(label)}

    train_ds = load_dataset(read_dataset, filepath="data/labeled/train/train.txt", lazy=False)
    dev_ds = load_dataset(read_dataset, filepath="data/labeled/train/dev.txt", lazy=False)

    # 数据预处理
    def convert_example(example, tokenizer, max_seq_length):
        encoded = tokenizer(text=example["text"], max_seq_len=max_seq_length)
        encoded["labels"] = [example["label"]]
        return encoded

    train_ds = train_ds.map(convert_example, fn_kwargs={"tokenizer": tokenizer, "max_seq_length": MAX_SEQ_LENGTH})
    dev_ds = dev_ds.map(convert_example, fn_kwargs={"tokenizer": tokenizer, "max_seq_length": MAX_SEQ_LENGTH})

    # 加载模型
    model = ErnieForSequenceClassification.from_pretrained(MODEL_NAME, num_classes=3)

    # 训练参数
    training_args = TrainingArguments(
        output_dir="models/ernie/checkpoint",
        num_train_epochs=EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        learning_rate=LEARNING_RATE,
        max_seq_length=MAX_SEQ_LENGTH,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="accuracy",
    )

    # 训练
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=dev_ds,
    )

    trainer.train()

    # 评估
    eval_results = trainer.evaluate()
    print(f"\n评估结果: {eval_results}")

    # 保存模型
    model.save_pretrained("models/ernie/final")
    tokenizer.save_pretrained("models/ernie/final")
    print(f"模型保存到: models/ernie/final")


if __name__ == "__main__":
    print("=" * 60)
    print("  ERNIE情感分类模型训练")
    print("=" * 60)

    # 1. 准备数据
    print("\n[1/2] 准备训练数据...")
    prepare_training_data()

    # 2. 训练模型
    print("\n[2/2] 训练ERNIE模型...")
    train_ernie()

    print("\n" + "=" * 60)
    print("训练完成！")
